package pageObjectModel_Pages;

import baseClass.AppTest;
import utilities.selenium.ExcelDataConfig;

public class ATOErrorFixes extends AppTest {
	
	/*Class is used to handle different errors that occurs in ATO. For each error we have action item listed in ATOErrorsSheet.
	 * Specific methods are run based on the error.*/
	
	public static void errorFixing(String error) throws Exception {
	/*	All errors are listed in the ATOErrorsSheet.xlsx
	 * For each error a action is used to run respective methods and all actions are used with switch statement as shown below:*/
		String errorAction = ExcelDataConfig.getParameterValue(errorSheetPath,"Errors", error);
		switch(errorAction) {
		   case "UpdateRecipientAddress" : 
			   // Recipient address will be updated.
			   AccountsAndContactsPage.updateRecipientAddress();
		     
		      break;
		      
		   case "Contact record does NOT have any valid MAIL ADDRESS" :
			     
			  break;  
			      
		   case "Please process all UNMAPPED ITEMS before proceeding " :
			     
			  break;
			      
		   case "BillToPerson" :
			   // BillTo person will be selected from drop down and estimated book date will be changed to current date.
			     VerifyPage.billToPerson();
			  break;
			      
		   case "Recipient is required" :
			     
			  break;
			      
		   case "DeleteRecipient" :
			   // Recipient will be deleted.
			   AccountsAndContactsPage.deleteRecipient();
			  break;
			      
		}
	}

}
