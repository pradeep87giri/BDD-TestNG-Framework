
package utilities.selenium;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import utilities.exceptions.DataFileNotFoundException;
import utilities.exceptions.EnvironmentParametersNotFoundException;
import utilities.parameters.ParameterTable;

/**
 * This class reads the data contained in the worksheet of an Excel file It uses
 * POI library utilities to a handle Excel file "key" column contains the
 * attribute and "value" column contains the value of the attribute
 * 
 */

public class ExcelDataConfig {

	private static Properties properties = new Properties();

	public static void initialize(String filePath, String sheetName) throws Exception {
		XSSFWorkbook excelWBook = null;

		try {

			// Access the required test data sheet
			excelWBook = new XSSFWorkbook(new FileInputStream(filePath));
			XSSFSheet configWSheet = excelWBook.getSheet(sheetName);

			importPropertiesFromXLS(configWSheet);
		} finally {
			if (excelWBook != null) {
				excelWBook.close();
			}
		}
	}

	public static String getProperty(String key) {
		return properties.getProperty(key);
	}

	private static void importPropertiesFromXLS(XSSFSheet configWSheet) {
		properties.clear();
		int rowCount = configWSheet.getPhysicalNumberOfRows();
		for (int i = 1; i < rowCount; i++) {
			String key = getCellValue(configWSheet, i, 0);
			String value = getCellValue(configWSheet, i, 1);
			if (key != null && value != null) {
				addProperty(key, value);
			}
		}

	}

	private static String getCellValue(XSSFSheet sheet, int rownum, int cellnum) {
		String value = "";
		XSSFCell cell = sheet.getRow(rownum).getCell(cellnum);
		if (cell == null) {
			return null;
		}
		if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
			value = String.valueOf(cell.getNumericCellValue());
		} else if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
			value = cell.getStringCellValue();
		} else if (cell.getCellType() == Cell.CELL_TYPE_BOOLEAN) {
			value = String.valueOf(cell.getBooleanCellValue());
		} else if (cell.getCellType() == Cell.CELL_TYPE_FORMULA) {
			if (cell.getCachedFormulaResultType() == Cell.CELL_TYPE_NUMERIC) {
				value = String.valueOf(cell.getNumericCellValue());
			} else if (cell.getCachedFormulaResultType() == Cell.CELL_TYPE_STRING) {
				value = cell.getStringCellValue();
			} else if (cell.getCachedFormulaResultType() == Cell.CELL_TYPE_BOOLEAN) {
				value = String.valueOf(cell.getBooleanCellValue());
			}
		}

		return value;
	}

	private static void addProperty(String key, String value) {
		properties.put(key, value);
	}

	public static String getParameterValue(String filePath, String sheetName, String parameterName) throws Exception {
		String parameterVal = null;

		File file = new File(filePath);
		FileInputStream fis = new FileInputStream(file);

		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet(sheetName);

		int totalRows = sh.getLastRowNum();
		int totalCols = sh.getRow(0).getLastCellNum();
		// System.out.println("Total no of Rows : " + totalRows);
		// System.out.println("Total no of Columns : " + totalCols);

		for (int i = 1; i <= totalRows; i++) {
			if (parameterName.equalsIgnoreCase(sh.getRow(i).getCell(0).getStringCellValue())) {
				try {
					parameterVal = sh.getRow(i).getCell(1).getStringCellValue();
					break;
				} catch (Exception e) {
					parameterVal = String.valueOf((int) (sh.getRow(i).getCell(1).getNumericCellValue()));
					break;
				}

				

			}
			wb.close();
		}
		return parameterVal;
	}

	public static String getParameterValueUsingColumnName(String filePath, String sheetName, String parameterName,
			String columnName) throws Exception {
		String parameterVal = null;

		File file = new File(filePath);
		FileInputStream fis = new FileInputStream(file);

		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet(sheetName);

		int totalRows = sh.getLastRowNum();
		int totalCols = sh.getRow(0).getLastCellNum();
		// System.out.println("Total no of Rows : " + totalRows);
		// System.out.println("Total no of Columns : " + totalCols);

		for (int i = 1; i <= totalRows; i++) {
			if (parameterName.equalsIgnoreCase(sh.getRow(i).getCell(0).getStringCellValue())) {
				for (int j = 0; j <= totalCols - 1; j++) {
					if (columnName.equalsIgnoreCase(sh.getRow(0).getCell(j).getStringCellValue())) {
						try {
							parameterVal = sh.getRow(i).getCell(j).getStringCellValue();
							Log.printInfo(columnName + " value is " + parameterVal);
							break;
						} catch (Exception e) {
							parameterVal = String.valueOf((int) (sh.getRow(i).getCell(j).getNumericCellValue()));
							Log.printInfo(columnName + " value is " + parameterVal);
							break;
						}

					}
				}
				break;
				}
		}
		wb.close();
		return parameterVal;
	}

	public static void createExcelSheet(String filePath, String sheetName, int noOfColumns, String columnName1)
			throws Exception {

		File file = new File(filePath);
		FileInputStream fis = new FileInputStream(file);

		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.createSheet(sheetName);

		// Create a Font for styling header cells
		Font headerFont = wb.createFont();
		headerFont.setBold(true);
		headerFont.setFontHeightInPoints((short) 14);
		headerFont.setColor(IndexedColors.RED.getIndex());

		// Create a CellStyle with the font
		CellStyle headerCellStyle = wb.createCellStyle();
		headerCellStyle.setFont(headerFont);

		// Create a Row
		Row headerRow = sh.createRow(0);

		// Create cells
		for (int i = 0; i < noOfColumns; i++) {
			Cell cell = headerRow.createCell(i);
			// cell.setCellValue(noOfColumns[i]);
			cell.setCellStyle(headerCellStyle);
		}

		wb.close();
	}
}