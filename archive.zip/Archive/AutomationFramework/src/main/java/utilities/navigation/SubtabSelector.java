
package utilities.navigation;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.testng.Assert;

import utilities.elements.Page;
import utilities.selenium.Driver;
import utilities.selenium.Log;

/**
 * TODO: Javadocs
 * 
 *
 */
public class SubtabSelector
{
	/**
	 * TODO: Javadocs
	 * 
	 *
	 */
	public static void click(String subtabText)
	{
		try{Log.printAction("Selecting '" + subtabText + "' subtab");

		// Verifies that the it only clicks the subtabs as some side menu items
		// can have the same descriptions
		Page.findElement(By.cssSelector("li[ot='SiebViewLink'][un='" + subtabText + "']"), "'" + subtabText + "' subtab").click();
		Driver.waitForAjaxToComplete();
		Driver.pause(3);
		}
		catch (NoSuchElementException e)
		{
			Page.findElement(By.id("j_s_vctrl_div_tabScreen"), "Third Level View Bar").click();
			Page.findElement(By.cssSelector("option[un='" + subtabText + "']"), "'" + subtabText + "' subtab").click();
		}
		catch (Exception e)
		{
			Assert.fail("Unable to select '" + subtabText + "' subtab");
		}
	}

	/**
	 * TODO: Javadocs
	 * 
	 * @param subtabText
	 * @param index
	 */
	public static void click(String subtabText, int index)
	{
		Log.printAction("Selecting '" + subtabText + "' subtab");

		// Verifies that the it only clicks the subtabs as some side menu items
		// can have the same descriptions
		Page.findElements(By.cssSelector("li[ot='SiebViewLink'][un='" + subtabText + "']"), "'" + subtabText + "' subtab").get(index).click();

		Driver.waitForAjaxToComplete();
	}
}
