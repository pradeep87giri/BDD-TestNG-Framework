package stepDefinitions;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObjectModel_Pages.ATOPage;
import utilities.selenium.Log;

public class SummaryPageValidations {

	@When("^Click on Release Order$")
	public void click_on_Release_Order() throws Throwable {
		Log.printWorkflow("click_on_Release_Order");
	    ATOPage.clickReleaseOrder();
	}

	@When("^Click on Remove Order$")
	public void click_on_Remove_Order() throws Throwable {
		Log.printWorkflow("Click on Remove Order");
	   ATOPage.clickRemoveOrder();
	}

	@When("^Click on Reset Order$")
	public void click_on_Reset_Order() throws Throwable {
		Log.printWorkflow("Click on Reset Order");
		 ATOPage.clickResetOrder();
	}

	@Then("^Validate Summary page$")
	public void validate_Summary_page() throws Throwable {
	   
	}
	
	
}
