package stepDefinitions;

import cucumber.api.java.en.Then;
import pageObjectModel_Pages.ATOPage;
import utilities.selenium.Log;

public class CGIReportLinkValidation {

	@Then("^Click on CGI Report Link and Validate$")
	public void click_on_CGI_Report_Link_and_Validate() throws Throwable {
		Log.printWorkflow("Click on CGI Report Link and Validate");
	   ATOPage.clickCGIReport(OrderProcessFlow.orderNum);
	}
	
}
