
package utilities.elements;

import java.util.Random;

import org.openqa.selenium.support.ui.Select;

/**
 * <p>
 * <code>DummyData</code> is a statically referenced class that generates random strings of data.
 * </p>
 * <p>
 * <code>DummyData</code> is primarily used when filling out fields and selecting from lists in the
 * UI of the system under test, though the methods can be applied for any situation where you wish
 * to generate random data.
 * </p>
 * 
 */
public class DummyData
{
	static Random random = new Random();

	/**
	 * <p>
	 * Returns a string starting with <code>name</code> followed by the system time in milliseconds.
	 * </p>
	 * 
	 * @param name A <code>String</code> representing a logical name for the <code>String</code> you
	 *            wish to generate, such as the name of the field yoi are generating text for.
	 * @returns A <code>String</code> staring with <code>name</code> in all uppercase letters
	 *          followed by a dash, and the system time in milliseconds.
	 */
	public static String createRandomString(String name)
	{
		long time = System.currentTimeMillis();

		return name.toUpperCase() + "-" + time;
	}

	/**
	 * <p>
	 * Returns a string representation of a number between 0 and 100
	 * </p>
	 * 
	 * @return A <code>String</code> representing a number between 0 and 100
	 */
	public static String createRandomNumber()
	{
		return Integer.toString(random.nextInt(100));
	}

	public static String createMillisecondString()
	{
		return Long.toString(System.currentTimeMillis());
	}

	/**
	 * <p>
	 * Returns a random number between <code>min</code> (inclusive) and <code>max</code>
	 * (exclusive).
	 * </p>
	 * 
	 * @param min An <code>int</code> representing the floor of the number range, inclusive.
	 * @param max An <code>int</code> representing the ceiling of the number range, exclusive.
	 * @return An <code>int</code> between <code>min</code> (inclusive) and <code>max</code>
	 *         (exclusive).
	 */
	public static int createRandomNumberRange(int min, int max)
	{
		if (min == max)
			return min;
		else
			return random.nextInt(max - min) + min;
	}
	/**
	 * Selects a random option in the specified dropdown list.
	 * <p>
	 * -WARNING- Will NOT work with input dropdown lists.
	 * 
	 * @param Picklist The name of the dropdown to select random option from.
	 */
	public static void selectRandomListOption(Select Picklist)
	{
		int size = Picklist.getOptions().size();
		int rand = random.nextInt(size);

		// Forces the picklist to not pick the default option if one is present.
		if (size > 0)
		{
			if (Picklist.getOptions().get(rand).getText().equals("Select Session Category") || Picklist.getOptions().get(rand).getText().equals(""))
				Picklist.selectByIndex(1);
			else
				Picklist.selectByIndex(rand);
		}
	}

	/**
	 * Selects a random option specified by the range. This is used if you don't want to search
	 * through the entire list.
	 * <p>
	 * -WARNING- Will NOT work with input dropdown lists.
	 * 
	 * @param Picklist The name of the dropdown to select random option from.
	 * @param min An int of lowest number in the range.
	 * @param max An int of highest number in the range.
	 */
	public static void selectRandomListOption(Select Picklist, int min, int max)
	{
		int size = Picklist.getOptions().size();
		int rand = random.nextInt(random.nextInt(max - min) + min);

		if (size > 0)
		{
			if (Picklist.getOptions().get(rand).getText().equals("Unassigned") || Picklist.getOptions().get(rand).getText().equals("unknown"))
				Picklist.selectByIndex(1);
			else
				Picklist.selectByIndex(rand);
		}
	}
}