package utilities.commonPage;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import utilities.elements.UIButton;
import utilities.elements.UIPage;
import utilities.selenium.Driver;
import utilities.selenium.Log;
import utilities.selenium.SeleniumBaseTest;

public class LoginPage extends Driver {

	public static void goTo()
	{
		//Log.printWorkflow("Navigating to login page");
		
		Driver.Instance.get(SeleniumBaseTest.url);
	}

	/*public static void login(String userID, String password)
	{
		Log.printWorkflow("Logging in as '" + userID + "'");

		Log.printAction("Entering '" + userID + "' in the 'User ID' field");
		UIPage.findElement(By.cssSelector("input[title='User ID']"), "User name input field").sendKeys(userID);
		UIPage.findElement(By.cssSelector("input[title='Password']"), "Password input field").sendKeys(password);

		UIButton.click(By.cssSelector("a[onclick^='SWEExecuteLogin']"),"Login");
		
		Driver.waitForAjaxToComplete();
	}*/
	
	public static void loginAuto(String user,String password) {

		Log.printWorkflow("Logging in as '" + user + "'");
			
		int delay = 6000; // in milliseconds

		// use ./autoit/autoitscript.exe as the relative path to the project directory
		// AutoIT method to handle SSO Windows login dialog
		
		
		try
		{
			Log.printInfo("Executing AutoIT script to enter in user credentials");

			Process p = Runtime.getRuntime().exec("./autoit/CPPAuth" + SeleniumBaseTest.currentBrowser + ".exe " + user + " " + password + " " + delay);
			p.waitFor(120, TimeUnit.SECONDS);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
	}
}
