package utilities.elements;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import utilities.selenium.Driver;
import utilities.selenium.Log;

public class UIField {

	public static class InputDropdown
	{
		/**
		 * Clicks the specified option in a specified InputDropdown field.
		 * 
		 * @param arrowLocator Unique locator for a WebElement. <i>Ex)
		 *            By.cssSelector("input[id='exampleID']")</i>.
		 * @param listOptions Unique locator for the list element. <i>Ex)
		 *            By.cssSelector("input[id='exampleID']")</i>.
		 * @param fieldName The String of the name of the inputDropdown field for logging purposes.
		 * @param option The String of the option to be selected from the InputDropdown field.
		 */
		public static void selectOption(By arrowLocator, By listOptions, String fieldName, String option)
		{
			Log.printInfo("Selecting option '" + option + "' from '" + fieldName + "' field");

		
			List<WebElement> ListOptions;

			new WebDriverWait(Driver.Instance, Driver.timeOut).until(ExpectedConditions.elementToBeClickable(arrowLocator));
						
			for (int seconds = 0;; seconds++)
			{
				try
				{
					// Click the arrow
					UIPage.findElement(arrowLocator, "List arrow for '" + fieldName + "' field").click();	
				}
				catch (Exception e) {}

				ListOptions = UIPage.findElements(listOptions, "List options");

				if (ListOptions.size() > 0 || seconds > Driver.timeOut)
				{
					break;
				}
			    Driver.pause(1);
			    System.out.println("Waiting");
			}
			Driver.pause(2);
			for (WebElement Option : ListOptions)
			{
				if (Option.getText().equals(option))
				{
					try
					{
						new WebDriverWait(Driver.Instance, Driver.timeOut).until(ExpectedConditions.elementToBeClickable(Option));
						Option.click();
						return;
					}
					catch (ElementNotVisibleException e)
					{
						Actions build = new Actions(Driver.Instance);
						build.moveToElement(Option, 0, 0).click().build().perform();
						return;
					}
				}
			}

			Assert.fail("'" + option + "' was not found in '" + fieldName + "'");
		}
		
		public static void selectOptionContains(By arrowLocator, By listOptions, String fieldName, String option)
		{
			Log.printInfo("Selecting option '" + option + "' from '" + fieldName + "' field");

		
			List<WebElement> ListOptions;

			new WebDriverWait(Driver.Instance, Driver.timeOut).until(ExpectedConditions.elementToBeClickable(arrowLocator));
						
			for (int seconds = 0;; seconds++)
			{
				try
				{
					// Click the arrow
					UIPage.findElement(arrowLocator, "List arrow for '" + fieldName + "' field").click();	
				}
				catch (Exception e) {}

				ListOptions = UIPage.findElements(listOptions, "List options");

				if (ListOptions.size() > 0 || seconds > Driver.timeOut)
				{
					break;
				}
			    Driver.pause(1);
			    System.out.println("Waiting");
			}
			Driver.pause(5);
			for (WebElement Option : ListOptions)
			{
				System.out.println(Option.getText() + "OPtion");
				if (Option.getText().contains(option))
				{
					try
					{
						new WebDriverWait(Driver.Instance, Driver.timeOut).until(ExpectedConditions.elementToBeClickable(Option));
						Option.click();
						return;
					}
					catch (ElementNotVisibleException e)
					{
						Actions build = new Actions(Driver.Instance);
						build.moveToElement(Option, 0, 0).click().build().perform();
						return;
					}
				}
			}

			Assert.fail("'" + option + "' was not found in '" + fieldName + "'");
		}
		
		/**
		 * Clicks a random option in a specified inputDropdown field.
		 * 
		 * @param arrowLocator Unique locator for a WebElement. <i>Ex)
		 *            By.cssSelector("input[id='exampleID']")</i>.
		 * @param listOptions Unique locator for the list element. <i>Ex)
		 *            By.cssSelector("input[id='exampleID']")</i>.
		 * @param fieldName The String of the InputDropdown field name.
		 */
		public static void selectRandomOption(By arrowLocator, By listOptions, String fieldName)
		{
			Log.printInfo("Selecting random option from '" + fieldName + "' field");
			
			List<WebElement> ListOptions;
			int randomIndex;

			new WebDriverWait(Driver.Instance, Driver.timeOut).until(ExpectedConditions.elementToBeClickable(arrowLocator));
			
			for (int seconds = 0;; seconds++)
			{
				try
				{
					// Click the arrow
					UIPage.findElement(arrowLocator, "List arrow for '" + fieldName + "' field").click();
				}
				catch (Exception e) {}
				
				ListOptions = UIPage.findElements(listOptions, "List options");

				if (ListOptions.size() > 0 || seconds > Driver.timeOut)
				{
					break;
				}
			    Driver.pause(1);
			}	
				
			randomIndex = DummyData.createRandomNumberRange(0, ListOptions.size());
			
			try
			{
				ListOptions.get(randomIndex).click();
			}
			catch (ElementNotVisibleException e1)
			{
				Actions build = new Actions(Driver.Instance);
				build.moveToElement(ListOptions.get(randomIndex), 0, 0).click().build().perform();
			}
			catch (Exception e2)
			{
				Assert.fail("Unable to select random option from '" + fieldName + "' field");
			}
		}
	
	}

	/**
	 * Field.Text is a statically referenced class for interacting with text-based input fields.
	 */
	public static class Text
	{
		/**
		 * If the text field doesn't follow the normal css selector set for all text fields on the
		 * site, then this method handles the small cases where there a few fields that have
		 * different properties. This is used to avoid creating multiple methods for different
		 * elements that might only be used a very small number of times.
		 * 
		 * @param locator Unique locator for a WebElement. <i>Ex)
		 *            By.cssSelector("input[id='exampleID']")</i>.
		 * @param fieldName A String of the name of the field for logging purposes
		 * @param text A String of the text that is going to be inputed into the field
		 */
		public static void setText(By locator, String fieldName, String text)
		{
			if (fieldName.contains("Password"))
				Log.printInfo("Entering '********' in '" + fieldName + "' text field");
			else
				Log.printInfo("Entering '" + text + "' in '" + fieldName + "' text field");

			
			WebElement TextField = UIPage.findElement(locator, "'" + fieldName + "' text field");

			TextField.clear();
			//TextField.sendKeys(text + Keys.TAB);
			TextField.sendKeys(text);
		}
		
		
		
		/**
		 * Returns the string contained within a text field.
		 * 
		 * @param locator Unique locator for a WebElement. <i>Ex)
		 *            By.cssSelector("input[id='exampleID']")</i>.
		 * @param fieldName A String representing the field name for logging purposes.
		 * @returns A String of the text contained within the text field.
		 */
		public static String getText(By locator, String fieldName)
		{
			Log.printInfo("Getting text from '" + fieldName + "' text field");
		
			
			String text = UIPage.findElement(locator, "'" + fieldName + "' text field").getText();

			Log.printInfo("'" + fieldName + "' text field contains text '" + text + "'");

			return text;
		}
		
		
		public static String getValue(By locator, String fieldName)
		{
			Log.printInfo("Getting text from '" + fieldName + "' text field");
			
			String text = UIPage.findElement(locator, "'" + fieldName + "' text field").getAttribute("value");

			Log.printInfo("'" + fieldName + "' text field contains text '" + text + "'");

			return text;
		}
	}
	/**
	 * Field.SelectDropdown is a statically referenced class for interacting with list-based
	 * <b>"SELECT"</b> fields.
	 */
	public static class SelectDropdown
	{
		/**
		 * Find a specified select dropdown list and select the specified option in that list.
		 * 
		 * @param locator Unique locator for a WebElement. <i>Ex)
		 *            By.cssSelector("input[id='exampleID']")</i>.
		 * @param dropdownFieldName A string with the name of the field for logging purposes.
		 * @param option A string containing the name of the option to select.
		 */
		public static void selectOption(By locator, String dropdownFieldName, String option)
		{
			Log.printInfo("Selecting option '" + option + "' from the select list '" + dropdownFieldName + "'");

			WebElement Element = UIPage.findElement(locator, "'" + dropdownFieldName + "' dropdown");
			Select DD = new Select(Element);

			DD.selectByVisibleText(option);
		}
	}

}
