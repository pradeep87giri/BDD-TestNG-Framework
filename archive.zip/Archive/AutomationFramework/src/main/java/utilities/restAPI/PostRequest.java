package utilities.restAPI;

import static io.restassured.RestAssured.*;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import utilities.selenium.Log;

public class PostRequest {

	public static void postRequestEditData(String uri, String fieldname, String postValue) {
		try {
			Response resp = given().
							body(postValue).when().contentType(ContentType.JSON).post(uri + "/posts");

			Log.printInfo("Post request changes are made successfully and changed values are : " + resp.asString());
		} catch (Exception e) {
			Log.printInfo("Post request was not successful for : " + fieldname);
		}
	}
}
