package pageObjectModel_Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import baseClass.AppTest;
import utilities.elements.Field.Text;
import utilities.elements.Page;
import utilities.selenium.ExcelDataConfig;
import utilities.selenium.Log;

public class AccountsAndContactsPage extends AppTest {
	
	/*Contains different methods for performing actions on accounts and 
	 * contact page like updating recipient address, delete a contact, add new contact etc.*/

	public static void updateRecipientAddress() throws Exception {
		/*Using below code recipient address details will be fetched from the ATOErrorsSheet excel 
		 * and inserted for fixing the recipient address issue.*/
		String recipientAddressEditOption = ExcelDataConfig.getParameterValue(sheetPath, "AccountsAndContactsPage",
				"recipientAddressEditOption");
		String CountryDropdown = ExcelDataConfig.getParameterValue(sheetPath, "AccountsAndContactsPage",
				"CountryDropdown");

		Page.clickLink(By.xpath(recipientAddressEditOption), "EditOption");
		Page.clickButton(By.xpath(CountryDropdown), "CountryDropdown");
		String country = ExcelDataConfig.getParameterValueUsingColumnName(errorSheetPath, "ErrorDataSheet",
				"UpdateRecipientAddress", "Country");
		String deliveryLine = ExcelDataConfig.getParameterValueUsingColumnName(errorSheetPath, "ErrorDataSheet",
				"UpdateRecipientAddress", "Delivery Line");
		String city = ExcelDataConfig.getParameterValueUsingColumnName(errorSheetPath, "ErrorDataSheet",
				"UpdateRecipientAddress", "City");
		String state = ExcelDataConfig.getParameterValueUsingColumnName(errorSheetPath, "ErrorDataSheet",
				"UpdateRecipientAddress", "State");
		String zip = ExcelDataConfig.getParameterValueUsingColumnName(errorSheetPath, "ErrorDataSheet",
				"UpdateRecipientAddress", "Zip");
		/*Special check is added to select the matching country from the country list. Country should be same as mentioned in the excel.*/
		List<WebElement> countrylist = Page.findElements(By.xpath("//*[contains(text(),'" + country + "')]"),
				"CountryValue");
		for (WebElement countryValue : countrylist) {
			String countryName = countryValue.getText();
			if (countryName.equalsIgnoreCase(country)) {
				countryValue.click();
				break;
			}
		}

		String deliveryLineOption = ExcelDataConfig.getParameterValue(sheetPath, "AccountsAndContactsPage",
				"deliveryLineOption");
		String cityOption = ExcelDataConfig.getParameterValue(sheetPath, "AccountsAndContactsPage", "cityOption");
		String stateDropdown = ExcelDataConfig.getParameterValue(sheetPath, "AccountsAndContactsPage", "stateDropdown");
		Text.setText(By.xpath(deliveryLineOption), "DeliveryLine", deliveryLine);
		Text.setText(By.xpath(cityOption), "City", city);
		Page.clickButton(By.xpath(stateDropdown), "StateDropdown");
		/*Special check is added to select the matching state from the state list. State should be same as mentioned in the excel.*/
		List<WebElement> statelist = Page.findElements(By.xpath("//*[contains(text(),'" + state + "')]"), "StateValue");
		for (WebElement stateValue : statelist) {
			String stateName = stateValue.getText();
			if (stateName.equalsIgnoreCase(state)) {
				stateValue.click();
				break;
			}
		}
		Text.setText(By.xpath("//*[@ng-model ='formContact.zip_NO']"), "Zip", zip);
		Page.clickLink(By.xpath("//*[contains(text(),'Submit')]"), "Submit");
		Log.printInfo("Recipient Address Updated");
		Thread.sleep(5000);
	}

	public static void deleteRecipient() throws Exception {
		// Recipient will be deleted when this method is called.
		Page.clickLink(By.xpath(
				"//*[@class='icon icon-error ng-isolate-scope material-icons']//following::md-icon[contains(text(),'delete')]"),
				"DeleteOption");
		Page.clickLink(By.xpath("//md-dialog-actions//button//span[contains(text(),'Yes')]"), "YesOption");
		Log.printInfo("Recipient Contact Deleted");
		Thread.sleep(5000);

	}
}
