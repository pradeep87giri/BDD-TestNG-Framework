package functional;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.relevantcodes.extentreports.LogStatus;

public class DBConnection extends MasterScriptMapping
{
//public variables 
	public Connection connection = null;
    public Statement statement = null;
    public ResultSet resultSet = null;
    public static String msAccDB = System.getProperty("user.dir")+"/Library/FrameworkDB.accdb";
    public static String dbURL = "jdbc:ucanaccess://" + msAccDB; 

public Connection  CreateConnection()
{
//Step 1: Loading or registering Oracle JDBC driver class
	try 
	{
		Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
	}
	catch(ClassNotFoundException cnfex) 
	{
		System.out.println("Problem in loading or "+ "registering MS Access JDBC driver");
		logger.log(LogStatus.FATAL, "<span style='color:steelblue;font-weight:bold;'>Exception Occured While Creating Connection URL : </span>"+cnfex);
	}
// Step 2: Opening database connection
	try 
	{
		connection = DriverManager.getConnection(dbURL);
		System.out.println("DB Connection Created");
	}
	catch(SQLException sqlex)
	{
		logger.log(LogStatus.FATAL, "<span style='color:steelblue;font-weight:bold;'>Exception Occured While Opening Connection URL : </span>"+sqlex);
	}
	return connection;
}
}
