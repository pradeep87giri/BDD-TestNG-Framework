package stepDefinitions;

import baseClass.AppTest;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObjectModel_Pages.ATOPage;
import utilities.parameters.ParameterTable;
import utilities.selenium.ExcelDataConfig;
import utilities.selenium.Log;

public class OrderProcessFlow {
	
	static String orderNum = null;

	@Given("^Open Browser and Open ATO URL$")
	public void open_Browser_and_Open_ATO_URL() throws Throwable {
		Log.printWorkflow("Open Browser and Open ATO URL");
		Log.printInfo("Opening Browser and URL");
	}

	@When("^Enter the Order Number$")
	public void enter_the_Order_Number() throws Throwable {
		orderNum = ExcelDataConfig.getParameterValue(AppTest.sheetPath, "OrderDetails", Hooks.scenarioName);
		String description = ExcelDataConfig.getParameterValueUsingColumnName(AppTest.sheetPath, "OrderDetails", Hooks.scenarioName, "Description");
		Log.printWorkflow("Enter the Order Number : " + orderNum + " - " + description);
		ATOPage.enterOrderNum(orderNum);
	}

	@When("^Click on Take Order$")
	public void click_on_Take_Order() throws Throwable {
		Log.printWorkflow("Click on Take Order");
		ATOPage.clickTakeOrder();
	}

	@When("^Fetch quote ID for the ordernum from AthenaQA database$")
	public void fetch_quote_ID_for_the_from_AthenaQA_database() throws Throwable {

		Log.printWorkflow("Fetch quote ID for the order from AthenaQA database");
		ATOPage.orderDetailsFromDatabase(orderNum);
		ATOPage.orderDetailsFromUI();

		ParameterTable.assertParameters("Order_Num", "UIOrder_Num", "DBOrder_Num");
		ParameterTable.assertParameters("Quote_ID", "UIQuote_ID", "DBQuote_ID");
		ParameterTable.assertParameters("Order_Status", "UIOrder_Status", "DBStaus_CD");
		ParameterTable.assertParameters("OrderClient_ID", "UIOrderClient_ID", "DBOrderClient_ID");
		ParameterTable.assertParameters("AE_Name", "UIOrderAE_Name", "DBAE_Name");
		/*
		 * Assert.assertEquals(ParameterTable.get("UIQuote_ID"),
		 * ParameterTable.get("DBQuote_ID"));
		 * Assert.assertEquals(ParameterTable.get("UIOrder_Status"),
		 * ParameterTable.get("DBStaus_CD"));
		 * Assert.assertEquals(ParameterTable.get("UIOrderClient_ID"),
		 * ParameterTable.get("DBOrderClient_ID"));
		 * Assert.assertEquals(ParameterTable.get("UIOrderAE_Name"),
		 * ParameterTable.get("DBAE_Name"));
		 */
	}

	@When("^Go To Mapping$")
	public void go_To_Mapping() throws Throwable {
		Log.printWorkflow("Go To Mapping");
		ATOPage.clickGoToMapping();
		ATOPage.captureErrors();

	}

	@When("^Enter Contacts Details$")
	public void enter_Contacts_Details() throws Throwable {
		Log.printWorkflow("Enter Contacts Details");
		ATOPage.enterVerificationDetails();
		
	}

	@When("^Enter Mapping Details$")
	public void enter_Mapping_Details() throws Throwable {
		Log.printWorkflow("Enter Mapping Details");
		ATOPage.enterMappingsDetails();
	}

	@When("^Enter Billing Details$")
	public void enter_Billing_Details() throws Throwable {
		Log.printWorkflow("Enter Billing Details");
		ATOPage.enterBillingDetails();
	}

	@When("^Click on Checkout$")
	public void click_on_Checkout_and_Submit_the_order() throws Throwable {
		Log.printWorkflow("Click on Checkout");
		ATOPage.CheckoutDetails();
	}

	@When("^Click on Proceed$")
	public void click_on_Proceed() throws Throwable {
		Log.printWorkflow("Click on Proceed");
		ATOPage.clickProceedbtn();
	}

	@Then("^Validate Review Order Page$")
	public void validate_Review_Order_Page() throws Throwable {
		Log.printWorkflow("Validate Review Order Page");
		ATOPage.validateReviewPage();
	}

}
