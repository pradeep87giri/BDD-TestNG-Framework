
package utilities.navigation;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import utilities.elements.Page;
import utilities.selenium.Driver;
import utilities.selenium.Log;

/**
 * TODO: Javadocs
 * 
 *
 */
public class Navigation
{
	/**
	 * <p>
	 * The <code>Home</code> class contains the <code>click</code> method that is used to select the
	 * <b>Home</b> button from the side bar hamburger menu.
	 * </p>
	 * 
	 *
	 */
	public static class Home
	{
		/**
		 * <p>
		 * Clicks the <b>Home</b> link on the side bar hamburger menu
		 * </p>
		 * <p>
		 * The input variable is the <i>linkText</i>
		 * </p>
		 * 
		 *
		 */
		public static class DHmenu
		{
			public static void click()
			{
				NavigationSelector.click("Home", "", "DH");
			}
		}

		public static class GSPmenu
		{
			public static void click()
			{
				NavigationSelector.click("Home", "", "GSP");
			}
		}
	}
	
	/**
	 * <p>
	 * The <code>Service Request</code> class contains the <code>click</code> method that is used to select the
	 * <b>Service Request</b> button from the side bar hamburger menu.
	 * </p>
	 * 
	 *
	 */
	public static class ManageSR
	{
		/**
		 * <p>
		 * Clicks the <b>Manage SR</b> link on the side bar hamburger menu
		 * </p>
		 * <p>
		 * The input variable is the <i>linkText</i>
		 * </p>
		 * 
		 *
		 */
		public static class DHmenu
		{
			public static void click()
			{
				NavigationSelector.click("Manage SR", "", "DH");
			}
		}

		public static class GSPmenu
		{
			public static void click()
			{
				NavigationSelector.click("Manage SR", "", "GSP");
			}
		}
	}

	/**
	 * <p>
	 * The <code>Accounts</code> class contains the <code>click</code> method that is used to select
	 * the <b>Accounts</b> button from the side bar hamburger menu.
	 * </p>
	 * 
	 *
	 */
	public static class Accounts
	{
		/**
		 * <p>
		 * Clicks the <b>Accounts</b> link on the side bar hamburger menu
		 * </p>
		 * <p>
		 * The input variable is the <i>linkText</i>
		 * </p>
		 * 
		 *
		 */
		public static class DHmenu
		{
			public static void click()
			{
				NavigationSelector.click("Accounts", "", "DH");
			}
		}

		public static class GSPmenu
		{
			public static void click()
			{
				NavigationSelector.click("Accounts", "", "GSP");
			}
		}

		/**
		 * <p>
		 * The <code>AccountsList</code> class is a sub class of <code>Accounts</code>. It contains
		 * the <code>click</code> method that is used to select the <b>Accounts List</b> link from
		 * the side bar hamburger menu. <b>Accounts List</b> is a sub link of <b>Accounts</b>
		 * </p>
		 * 
		 *
		 */
		public static class AccountsList
		{
			/**
			 * <p>
			 * Clicks the <b>Accounts List</b> link on the side bar hamburger menu
			 * </p>
			 * <p>
			 * The input variable is the <i>linkText</i>
			 * </p>
			 * 
			 *
			 */
			public static class DHmenu
			{
				public static void click()
				{
					NavigationSelector.click("Accounts", "Accounts List", "DH");
				}
			}

			public static class GSPmenu
			{
				public static void click()
				{
					NavigationSelector.click("Accounts", "Accounts List", "GSP");
				}
			}
		}

		/**
		 * <p>
		 * The <code>AccountsLookup</code> class is a sub class of <code>Accounts</code>. It
		 * contains the <code>click</code> method that is used to select the <b>Account Lookup</b>
		 * link from the side bar hamburger menu. <b>Accounts List</b> is a sub link of
		 * <b>Accounts</b>
		 * </p>
		 * 
		 *
		 */
		public static class AccountLookup
		{

			/**
			 * <p>
			 * Clicks the <b>Accounts Lookup</b> link on the side bar hamburger menu
			 * </p>
			 * <p>
			 * The input variable is the <i>linkText</i>
			 * </p>
			 */
			public static class DHmenu
			{
				public static void click()
				{
					NavigationSelector.click("Accounts", "Account Lookup", "DH");
				}
			}

			public static class GSPmenu
			{
				public static void click()
				{
					NavigationSelector.click("Accounts", "Account Lookup", "GSP");
				}
			}
		}
	}

	/**
	 * <p>
	 * The <code>Contacts</code> class contains the <code>click</code> method that is used to select
	 * the <b>Contacts</b> button from the side bar hamburger menu.
	 * </p>
	 * 
	 *
	 */
	public static class Contacts
	{
		/**
		 * <p>
		 * Clicks the <b>Contacts</b> link on the side bar hamburger menu
		 * </p>
		 * <p>
		 * The input variable is the <i>linkText</i>
		 * </p>
		 */
		public static class DHmenu
		{
			public static void click()
			{
				NavigationSelector.click("Contacts", "", "DH");
			}
		}

		public static class GSPmenu
		{
			public static void click()
			{
				NavigationSelector.click("Contacts", "", "GSP");
			}
		}
	}

	/**
	 * <p>
	 * The <code>Contacts</code> class contains the <code>click</code> method that is used to select
	 * the <b>Contacts</b> button from the side bar hamburger menu.
	 * </p>
	 *
	 */
	public static class Opportunities
	{
		/**
		 * <p>
		 * Clicks the <b>Opportunities</b> link on the side bar hamburger menu
		 * </p>
		 * <p>
		 * The input variable is the <i>linkText</i>
		 * </p>
		 * 
		 *
		 */
		public static class DHmenu
		{
			public static void click()
			{
				NavigationSelector.click("Opportunities", "", "DH");
			}
		}

		public static class GSPmenu
		{
			public static void click()
			{
				NavigationSelector.click("Opportunities", "", "GSP");
			}
		}
	}

	/**
	 * <p>
	 * The <code>DealHubRequest</code> class contains the <code>click</code> method that is used to
	 * select the <b>Deal Hub Requests</b> button from the side bar hamburger menu.
	 * </p>
	 * 
	 *
	 */
	public static class DealHubRequests
	{
		/**
		 * <p>
		 * Clicks the <b>Deal Hub Requests</b> link on the side bar hamburger menu
		 * </p>
		 * <p>
		 * The input variable is the <i>linkText</i>
		 * </p>
		 * 
		 *
		 */
		public static class DHmenu
		{
			public static void click()
			{
				NavigationSelector.click("Deal Hub Requests", "", "DH");
			}
		}

		public static class GSPmenu
		{
			public static void click()
			{
				NavigationSelector.click("Deal Hub Requests", "", "GSP");
			}
		}
	}

	/**
	 * <p>
	 * The <code>LogOut</code> method logs out of the current user session by clicking on the
	 * <b>file link</b>link on the top of the page then selecting the <b>logout</b> sub link from
	 * the list. Contains a <code>wait</code> function to check for a successful logout.
	 * </p>
	 * <p>
	 * <ul>
	 * <li>Variable used to find the <b>File</b> link is the <i>linkText</i> <code>File</code></li>
	 * <li>Variable used to find the <b>Log Out</b> link is the <i>partialLinkText</i>
	 * <code>Log Out</code></li>
	 * </ul>
	 * </p>
	 */
	public static void LogOut()
	{
		Log.printAction("Logging out");

		Page.findElement(By.linkText("File"), "'File' header link").click();
		Page.findElement(By.partialLinkText("Log Out"), "'Log Out' link").click();

		WebDriverWait wait = new WebDriverWait(Driver.Instance, 20);
		try
		{
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("a[onclick^='SWEExecuteLogin']"))).isDisplayed();
		}
		catch (Exception e)
		{}
	}

	/**
	 * <p>
	 * The <code>NavigationSelector</code> class contains the <code>click</code> method which is
	 * used elsewhere in the code to navigate to specific pages on the Deal Hub web page using the
	 * hamburger menu on the left side of the web site.
	 * </p>
	 * 
	 *
	 */
	public static class NavigationSelector
	{
		/**
		 * TODO: Javadocs
		 * 
		 * @param linkText
		 * @param subLinkText
		 * 
		 *
		 */
		public static void click(String linkText, String subLinkText, String menuGSPorDH)
		{
			Log.printWorkflow("Navigating to '" + linkText + "'");

			// When side bar is opened the id of the hamburger icon changes. Thus,
			// if it's already opened there is no need to clicking it again, unless you want to
			// close the side bar. Also, there are 2 different hamburger menus.

			WebDriverWait wait = new WebDriverWait(Driver.Instance, 10);
			try
			{
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("sidebarCloseButton"))).isDisplayed();
			}
			catch (Exception e)
			{}

			switch (menuGSPorDH)
			{
				case "GSP":
					if (!Driver.Instance.findElement(By.id("sidebarCloseButton")).isDisplayed())
						//Page.findElement(By.id("openSidebarButton"), "'Hamburger' sidebar icon").click(); HTML has changed. 'openSidebarButton' no more present
						//Modified by Kiran Sinha in May' 2016
						Page.findElement(By.cssSelector("div.apc-hamburger"), "'Hamburger' sidebar icon").click();
					break;
				case "DH":
					if (!Driver.Instance.findElement(By.id("sidebarCloseButton")).isDisplayed())
						Page.findElement(By.cssSelector("div[class='apc-hamburger']"), "'Hambruger' sidebaricon").click();
					break;
				default:
					Assert.fail("'" + menuGSPorDH + "' hamburger menu not found");
			}

			// try
			// {
			// if (Driver.Instance.findElement(By.cssSelector("div[class='apc-fullscreen
			// apc-menu-tree']"))
			// .isDisplayed())
			// Page.findElement(By.cssSelector("div[class='apc-hamburger']"), "'Hambruger' sidebar
			// icon").click();
			// }
			// catch (NoSuchElementException e)
			// {
			// if (!Driver.Instance.findElement(By.id("sidebarCloseButton")).isDisplayed())
			// Page.findElement(By.id("openSidebarButton"), "'Hamburger' sidebar icon").click();
			// }

			Log.printAction("Clicking '" + linkText + "' link");
			Page.findElement(By.cssSelector("li[ot='SiebScreen'][un='" + linkText + "']"), "'" + linkText + "' link").click();
			Driver.waitForAjaxToComplete();

			if (subLinkText != "")
			{
				Log.printAction("Clicking '" + subLinkText + "' link");
				Page.findElement(By.linkText(subLinkText), "'" + subLinkText + "' link").click();
				Driver.waitForAjaxToComplete();
			}
		}
		public static void clickExistingLink(String linkText, String subLinkText, String menuGSPorDH)
		{
			Log.printWorkflow("Navigating to '" + linkText + "'");

			// When side bar is opened the id of the hamburger icon changes. Thus,
			// if it's already opened there is no need to clicking it again, unless you want to
			// close the side bar. Also, there are 2 different hamburger menus.

			WebDriverWait wait = new WebDriverWait(Driver.Instance, 20);
			try
			{
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("sidebarCloseButton"))).isDisplayed();
			}
			catch (Exception e)
			{}

			switch (menuGSPorDH)
			{
				case "GSP":
					if (!Driver.Instance.findElement(By.id("sidebarCloseButton")).isDisplayed())
						Page.findElement(By.id("openSidebarButton"), "'Hamburger' sidebar icon").click();
					break;
				case "DH":
					if (!Driver.Instance.findElement(By.id("sidebarCloseButton")).isDisplayed())
						Page.findElement(By.cssSelector("div[class='apc-hamburger']"), "'Hambruger' sidebaricon").click();
					break;
				default:
					Assert.fail("'" + menuGSPorDH + "' hamburger menu not found");
			}
			Log.printInfo("Clicking '" + linkText + "' link");
			Page.findElement(By.cssSelector("li[ot='SiebViewLink'][un='" + linkText + "']"), "'" + linkText + "' link").click();
			Driver.waitForAjaxToComplete();

			if (subLinkText != "")
			{
				
				Log.printInfo("Clicking '" + subLinkText + "' link");
				Page.findElement(By.linkText(subLinkText), "'" + subLinkText + "' link").click();
			}
		}
	}

	
	
	
	/**
	 * <p>
	 * The <code>DHUseOnly</code> class contains the <code>click</code> method that is used to
	 * select the <b>DHUseOnly</b> button from the side bar hamburger menu.
	 * </p>
	 */
	public static class DHUseOnly
	{
		/**
		 * <p>
		 * Clicks the <b>Dh Use Only</b> link on the side bar hamburger menu
		 * </p>
		 * <p>
		 * The input variable is the <i>linkText</i>
		 * </p>
		 */
		public static class DHmenu
		{
			public static void click()
			{
				NavigationSelector.click("DH Use Only", "", "DH");
			}
		}
	
		public static class GSPmenu
		{
			public static void click()
			{
				NavigationSelector.click("DH Use Only", "", "GSP");
			}
		}
	}

	/**
	 * <p>
	 * The <code>VisualPipeline</code> class contains the <code>click</code> method that is used to
	 * select the <b>VisualPipeline</b> button from the side bar hamburger menu.
	 * </p>
	 */
	public static class VisualPipeline
	{
		/**
		 * <p>
		 * Clicks the <b>Visual Pipeline</b> link on the side bar hamburger menu
		 * </p>
		 * <p>
		 * The input variable is the <i>linkText</i>
		 * </p>
		 */
		public static class DHmenu
		{
			public static void click()
			{
				NavigationSelector.click("VisualPipeline", "", "DH");
			}
		}
	
		public static class GSPmenu
		{
			public static void click()
			{
				NavigationSelector.click("Visual Pipeline", "", "GSP");
				Driver.waitForAjaxToComplete();
			}
		}
	}
}
