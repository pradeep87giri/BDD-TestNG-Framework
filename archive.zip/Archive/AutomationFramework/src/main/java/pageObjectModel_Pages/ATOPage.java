package pageObjectModel_Pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import baseClass.AppTest;
import utilities.elements.Field;
import utilities.elements.Page;
import utilities.elements.UIButton;
import utilities.parameters.ParameterTable;
import utilities.selenium.Driver;
import utilities.selenium.ExcelDataConfig;
import utilities.selenium.Log;
import utilities.selenium.SeleniumBaseTest;

public class ATOPage extends AppTest {
	
	/*Contains different methods for performing actions on ATO homepage and Summary page
	 * like click actions on different buttons and links.*/

	public static void enterOrderNum(String ordernum) throws Exception {
		String ordertextbox = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails", "ordertextbox");
		Field.Text.setTextAndEnter(By.xpath(ordertextbox), "Search Box", ordernum);
		Thread.sleep(5000);

	}

	public static void clickReturnToSearch() throws Exception {
		Page.clickButton(By.xpath("//*[contains(text(),'Return to Search')]"), "Return To Search");
		Thread.sleep(2000);
		String ordertextbox = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails", "ordertextbox");
		Page.isPresentElement(By.xpath(ordertextbox), "ordertextbox");
		Log.printInfo("Search Order Page successfully loaded");
	}

	public static void clickCGIReport(String orderNum) throws Exception {
		String cGIReportLink = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails", "CGIReportLink");
		Page.clickLink(By.xpath(cGIReportLink), "CGI Report");
		Thread.sleep(5000);
		ArrayList<String> tabs2 = new ArrayList<String>(Driver.Instance.getWindowHandles());
		Driver.Instance.switchTo().window(tabs2.get(1));
		try {
			if (Page.getText(By.xpath("//*[@class = 'orderNum']//span[2]")).equals(orderNum)) {
				Log.printInfo("CGI Report loaded successfully - Validation Successful");
			}
		} catch (Exception e) {
			Log.printInfo("CGI Report not loaded successfully - Validation Not Successful");
		}

		Driver.Instance.close();
		Driver.Instance.switchTo().window(tabs2.get(0));
	}

	public static void clickTakeOrder() throws Exception {
		String takeOrderButton = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails", "takeOrderButton");
		String releaseOrderButton = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails",
				"releaseOrderButton");
		if (Page.isPresentElement(By.xpath(releaseOrderButton), "Release Order") > 0) {
			clickReleaseOrder();
		}
		UIButton.click("Take Order", By.xpath(takeOrderButton));
		Thread.sleep(10000);
	}

	public static void clickReleaseOrder() throws Exception {
		String releaseOrderButton = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails",
				"releaseOrderButton");
		UIButton.click("Release Order", By.xpath(releaseOrderButton));
		String releaseYesOption = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails", "releaseYesOption");
		UIButton.click("Yes option", By.xpath(releaseYesOption));
		Thread.sleep(5000);

	}

	public static void clickResetOrder() throws Exception {
		String resetOrderButton = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails", "resetOrderButton");
		UIButton.click("Reset Order", By.xpath(resetOrderButton));
		Thread.sleep(100000);

	}

	public static void clickRemoveOrder() throws Exception {
		String removeOrderButton = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails", "removeOrderButton");
		UIButton.click("Remove Order", By.xpath(removeOrderButton));
		Thread.sleep(5000);

	}

	public static void clickGoToMapping() throws Exception {
		String goToMappingButton = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails", "goToMappingButton");
		UIButton.click("Go To Mapping", By.xpath(goToMappingButton));
		Thread.sleep(5000);

	}

	public static void enterVerificationDetails() throws Exception {
		String verficationTab = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails", "verficationTab");
		UIButton.click("Verify Tab", By.xpath(verficationTab));
		Thread.sleep(5000);

	}

	public static void enterMappingsDetails() throws Exception {
		String mappingsTab = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails", "mappingsTab");
		UIButton.click("Mapping Tab", By.xpath(mappingsTab));
		Thread.sleep(5000);

	}

	public static void enterBillingDetails() throws Exception {
		String billingTab = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails", "billingTab");
		UIButton.click("Billing Tab", By.xpath(billingTab));
		Thread.sleep(5000);

	}

	public static void CheckoutDetails() throws Exception {
		String checkoutTab = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails", "checkoutTab");
		UIButton.click("Checkout Tab", By.xpath(checkoutTab));
		Thread.sleep(5000);

	}

	public static void clickProceedbtn() throws Exception {
		String proceedButton = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails", "proceedButton");
		UIButton.click("Proceed Button", By.xpath(proceedButton));
		Thread.sleep(25000);

	}

	public static void validateReviewPage() throws Exception {
		String orderReviewPage = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails", "orderReviewPage");
		String text = Page.getText(By.xpath(orderReviewPage));
		if (text.contains("Review Order")) {
			JFrame frame = new JFrame("JOptionPane showMessageDialog example");
			JOptionPane.showMessageDialog(frame, "Order Submitted Successfully", "ATO", JOptionPane.PLAIN_MESSAGE);
		}
		Thread.sleep(5000);

	}

	public static void selectContractValidationOption(String action) throws Exception {
		String contractVerificationDropdown = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails",
				"contractVerificationDropdown");
		Page.visiblityOfElementsWait(90, By.cssSelector(contractVerificationDropdown), "Contract Verification Needed");
		UIButton.click("Contract Verification Needed", By.cssSelector(contractVerificationDropdown));

		if (action.equalsIgnoreCase("Contract Matches")) {
			String contractMatchesOption = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails",
					"contractMatchesOption");
			UIButton.click("Contract Verification Value", By.xpath(contractMatchesOption));
		} else if (action.equalsIgnoreCase("Contract Do Not Match")) {
			String contractDoNotMatchOption = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails",
					"contractDoNotMatchOption");
			UIButton.click("Contract Verification Value", By.xpath(contractDoNotMatchOption));
		} else if (action.equalsIgnoreCase("Needs Further Review")) {
			String needsFurtherReview = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails",
					"needsFurtherReview");
			UIButton.click("Contract Verification Value", By.xpath(needsFurtherReview));
		}
		// SelectDropdown.selectOption(By.cssSelector(locatorvalue),"Contract
		// Verification Needed",action);
		// UIButton.click("Contract Verification Needed", By.xpath(locatorvalue));
		/*
		 * if(action.contains("Contract Match")) {
		 * //UIButton.click("Contract Match option",By.xpath("//*[@value='cm']"));
		 * Actions act = new Actions(Driver.Instance); WebElement wb =
		 * Driver.Instance.findElement(By.xpath("//*[@value='cm']"));
		 * act.doubleClick(wb); } else if(action.contains("Contract Do Not Match")) {
		 * UIButton.click("Contract Do not Match option",By.xpath("//*[@value='cnm']"));
		 * }
		 */
		String dropdownSubmit = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails", "dropdownSubmit");
		UIButton.click("Submit Button", By.xpath(dropdownSubmit));
		Thread.sleep(10000);
	}

	public static void orderDetailsFromDatabase(String orderNum) throws Exception {
		databaseValidations.ATOValidations.OrdNum(orderNum);

	}

	public static void orderDetailsFromUI() throws Exception {
		String locatorvalue = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails", "quoteIDUI");
		String quoteIDUI = Page.getText(By.xpath(locatorvalue));
		ParameterTable.add("UIQuote_ID", quoteIDUI);

		String locatorvalue1 = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails", "orderIDUI");
		String orderIDUI = Page.getText(By.xpath(locatorvalue1));
		orderIDUI = orderIDUI.replaceAll("[^0-9]", " ").trim();
		ParameterTable.add("UIOrder_Num", orderIDUI);

		String locatorvalue2 = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails", "orderStatusUI");
		String orderStatusUI = Page.getText(By.xpath(locatorvalue2));
		ParameterTable.add("UIOrder_Status", orderStatusUI);

		String locatorvalue3 = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails", "orderClientID");
		String orderClientID = Page.getText(By.xpath(locatorvalue3));
		ParameterTable.add("UIOrderClient_ID", orderClientID);

		String locatorvalue4 = ExcelDataConfig.getParameterValue(sheetPath, "LocatorsDetails", "orderAE_IT");
		String orderAE_IT = Page.getText(By.xpath(locatorvalue4));
		ParameterTable.add("UIOrderAE_Name", orderAE_IT);

	}

	public static void captureErrors() throws Exception {
		Log.printInfo("Checking for Errors");
		String errorLinkWithErrors = ExcelDataConfig.getParameterValue(sheetPath, "AccountsAndContactsPage",
				"errorLinkWithErrors");

		/*
		 * When order contains errors then locator value is errorLinkWithErrors. For
		 * errors value of errorLinkWithErrors > 0 and for no errors value of
		 * errorLinkWithErrors = 0.
		 */
		if (Page.isPresentElement(By.xpath(errorLinkWithErrors), "ErrorLinks") > 0) {
			Log.printWorkflow(
					"No Of Errors in the order : " + (Integer.parseInt(Page.getText(By.xpath(errorLinkWithErrors)))));
			Page.clickLink(By.xpath(errorLinkWithErrors), "ErrorsIcon");
			String errorLink = ExcelDataConfig.getParameterValue(sheetPath, "AccountsAndContactsPage", "errorLink");
			List<WebElement> errors = Page.findElements(By.xpath(errorLink), "Errors");
			errors.size();
			// Fetching error text using for loop
			for (WebElement errorText : errors) {
				String errText = errorText.getText();
				String texttrim = errText.replaceAll("error", " ").trim();
				Log.printInfo("Order contains : " + texttrim + " error");
				Page.clickLink(By.xpath("//*[contains(text(),'" + texttrim + "')]"), texttrim + " Error");
				// errorFixing method is used to fix the errors in ATO
				ATOErrorFixes.errorFixing(texttrim);
				break;
			}
			// Run captureErrors method again to find if order contains more errors.
			captureErrors();
		} else if (Page.isPresentElement(By.xpath(errorLinkWithErrors), "ErrorLink") == 0) {
			Log.printInfo("Order doesn't contain any error.");
		}

	}

}
