package utilities.elements;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import utilities.selenium.Driver;
import utilities.selenium.Log;

public class UIButton {

	public static void click(String buttonName, By selector) {
		Log.printAction("Clicking '" + buttonName + "' button");

		WebElement Button = Page.findElement(selector, "'" + buttonName + "' button");
	
		try {
			if(Button.isDisplayed()) {
			Button.click();
			Driver.waitForAjaxToComplete();
			} else {
				UIPage.visiblityOfElementsWait(40, selector, buttonName);
				Button.click();
				Driver.waitForAjaxToComplete();
			}
			
		} catch (ElementNotVisibleException e) {
			/*Actions build = new Actions(Driver.Instance);
			build.moveToElement(Button, 0, 0).click().build().perform();*/
			Log.printInfo(e.getMessage());
		}

	}

}
