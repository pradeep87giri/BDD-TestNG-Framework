package utilities.elements;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import utilities.selenium.Driver;

public class UIPage {


	/**
	 * Find and return a single WebElement with the specified selector and name.
	 * 
	 * @param by
	 *            Unique selector for a WebElement. Ex)
	 *            By.cssSelector("input[id='exampleID']").
	 * @param elementName
	 *            Logical name of element. This is what will show up in a
	 *            failure report if the element isn't found.
	 * @return WebElement if successfully found with given selector. Otherwise
	 *         returns null.
	 * @throws NoSuchElementException
	 *             If no matching elements are found.
	 */
	public static WebElement findElement(By by, String elementName) {

		
		
			try
			{
				
				return Driver.Instance.findElement(by);
			}
			
			catch (NoSuchElementException e2)
			{
				Assert.fail(elementName + " not found");
				return null;
			}	
		
	}

	/**
	 * Find and return multiple elements that share the specified selector and
	 * name. Useful for situations where you need to iterate through multiple
	 * similar elements. For example, if you need to gather elements in a table
	 * and pick a row at a particular index.
	 * 
	 * @param by
	 *            Unique selector for a WebElement. Ex)
	 *            By.cssSelector("input[id='exampleID']").
	 * @param elementName
	 *            Logical name of element. This is what will show up in a
	 *            failure report if the element isn't found.
	 * @return A list of WebElements all sharing the given selector.
	 * @throws NoSuchElementException
	 *             If no matching elements are found.
	 */
	public static List<WebElement> findElements(By by, String elementName)
	{
		
		try
		{
			return Driver.Instance.findElements(by);
		}
		
		catch (NoSuchElementException e2)
		{
			Assert.fail(elementName + " not found");
			return null;
		}
	}
	
	// Explicit Wait till the element is present
		public static void presenceOfElementWait(int timeout, By by, String elementName) {
			try {
				new WebDriverWait(Driver.Instance, timeout).until(ExpectedConditions.presenceOfElementLocated(by));
			} catch (NoSuchElementException e) {
				Assert.fail(elementName + "Not found");
			}
		}

		// Explicit Wait till the element is visible

		public static void visiblityOfElementWait(int timeout, By by, String elementName) {
			try {
				new WebDriverWait(Driver.Instance, timeout).until(ExpectedConditions.visibilityOfElementLocated(by));
			} catch (NoSuchElementException e) {
				Assert.fail(elementName + "Not found");
			}
		}

		
		
		public static void visiblityOfElementsWait(int timeout, By by, String elementName) {
			try {
				new WebDriverWait(Driver.Instance, timeout).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(by));
			} catch (NoSuchElementException e) {
				Assert.fail(elementName + "Not found");
			}
		}
		
		
		public static void elementToBeClickableWait(int timeout, By by, String elementName) {
			try {
				new WebDriverWait(Driver.Instance, timeout).until(ExpectedConditions.elementToBeClickable(by));
			} catch (NoSuchElementException e) {
				Assert.fail(elementName + "Not found");
			}
			}
			
			/*public static void elementsToBeClickableWait(int timeout, By by, String elementName) {
				try {
					new WebDriverWait(Driver.Instance, timeout).until(ExpectedConditions.el(by));
				} catch (NoSuchElementException e) {
					Assert.fail(elementName + "Not found");
				}
		}*/
		// Returns Select WebElement
		
		public static Select selectElement(By by,String elementName){
			WebElement element= findElement(by, elementName);
		return	new Select(element);
		}
		
		
}
