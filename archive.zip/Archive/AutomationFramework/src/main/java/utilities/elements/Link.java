
package utilities.elements;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import utilities.selenium.Driver;
import utilities.selenium.Log;

/**
 * <p>
 * <code>Link</code> is a statically referenced class for clicking various links with the
 * <i>User Interface</i> style, like DealHub.
 * </p>
 * <p>
 * Commonly reused links with their selectors predefined
 * to save some time and code. Uncommon links are referenced using one of a click() methods,
 * depending on if a completely unique selector is required
 * </p>
 */
public class Link
{
	/**
	 * <p>
	 * Clicks a link with an id property containing the string <code>linkName</code>.
	 * </p>
	 * <p>
	 * SUI links are located with this css selector:<br>
	 * <i>linkId</i>
	 * <i>linkName</i>
	 * </p>
	 * 
	 * @param linkId A <code>String</code> representing the id of the link, located in the
	 *            id property of the HTML tag of the desired link.
	 * @param linkName A <code>String</code> representing the name of the link as it appears on the web page.
	 */
	public static void click(String linkId, String linkName)
	{
		Log.printAction("Clicking '" + linkName + "' link");

		WebElement link = Page.findElement(By.id(linkId),  linkName);

		try
		{
			link.click();
		}
		catch (ElementNotVisibleException e)
		{
			Actions build = new Actions(Driver.Instance);
			build.moveToElement(link, 0, 0).click().build().perform();
		}
	}

	/**
	 * <p>
	 * Clicks a link with a css selector equal to the string <code>selector</code>. In this case,
	 * the string <code>linkName</code> should be the logical name of the button you wish to see
	 * in the output reports, it does not factor into finding the element.
	 * </p>
	 * 
	 * @param selector A <code>String</code> representing the css selector for the desired link
	 * @param linkName A <code>String</code> representing the name of the link as it appears on the web page
	 */
	public static void click(String linkName, By selector)
	{
		Log.printAction("Clicking '" + linkName + "' link");

		WebElement link = Page.findElement(selector, "'" + linkName + "' link");

		try
		{
			link.click();
			Driver.waitForAjaxToComplete();
		}
		catch (ElementNotVisibleException e)
		{
			Actions build = new Actions(Driver.Instance);
			build.moveToElement(link, 0, 0).click().build().perform();
		}
	}
}
