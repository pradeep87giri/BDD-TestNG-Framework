package testRunners;

import baseClass.AppTest;
import cucumber.api.CucumberOptions;

@CucumberOptions(features = "src/test/resources/Feature/OrderProcessFlow.feature",
tags = {"@SanityTest"},
glue={"stepDefinitions"},
format = { "pretty",
"html:target/site/OrderProcessFlow",
"rerun:target/rerun.txt",
"json:target/OrderProcessFlow.json" },dryRun=false,monochrome = true)


public class OrderProcessFlow extends AppTest{

}
