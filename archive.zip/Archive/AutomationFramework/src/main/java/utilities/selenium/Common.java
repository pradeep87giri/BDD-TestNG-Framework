
package utilities.selenium;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Random;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.NoSuchProviderException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

/**
 * This class reads the data contained in the worksheet of an Excel file It uses
 * POI library utilities to a handle Excel file "key" column contains the
 * attribute and "value" column contains the value of the attribute
 * 
 */

public class Common {
	public static void typeLoginPassword(String login, String password) {
		try {
			Robot robot = new Robot();
			// Getting rid of the authentication window
			robot.keyPress(KeyEvent.VK_ESCAPE);
			robot.keyRelease(KeyEvent.VK_ESCAPE);
			robot.delay(5000);

			// Typing login
			Common.putTextInClipboard(login);
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);
			robot.delay(3000);

			// Typing Password
			Common.putTextInClipboard(password);
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);
			robot.delay(3000);
		} catch (AWTException e) {
			e.printStackTrace();
		}
	}

	// Selects a random text from a list of strings separated by comma
	public static String getRandomText(String... s) {
		Random random = new Random();
		int index = random.nextInt(s.length);
		return (s[index]);
	}

	/**
	 * Presses any <key> from keyboard
	 * 
	 */
	public static void pressKey(Keys key) {

		Actions action = new Actions(Driver.Instance);
		Log.printAction("Pressing 'Key'  " + key + "on keyboard");
		action.sendKeys(key).build().perform();

	}

	/**
	 * Pastes text added to clipboard
	 * 
	 */
	public static void pasteTextFromClipboard() {
		Actions action = new Actions(Driver.Instance);
		action.keyDown(Keys.LEFT_CONTROL).perform();
		action.sendKeys("v").perform();
		action.keyUp(Keys.LEFT_CONTROL).perform();
	}

	/**
	 * Adds text to clipboard
	 * 
	 */
	public static String putTextInClipboard(String text) {
		Toolkit defaultToolkit = Toolkit.getDefaultToolkit();
		Clipboard systemClipboard = defaultToolkit.getSystemClipboard();

		systemClipboard.setContents(new StringSelection(text), null);
		// String result =
		// systemClipboard.getData(DataFlavor.stringFlavor).toString();

		try {
			String result = systemClipboard.getData(DataFlavor.stringFlavor).toString();
			return result;
			// System.out.println("String from Clipboard:" + result);
		} catch (UnsupportedFlavorException e) {
			// TODO Auto-generated catch block
			Log.printWorkflow(e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Log.printWorkflow(e.getMessage());
		}

		return null;
	}

	/**
	 * To read first five emails from exchange server
	 * 
	 * @param username
	 *            - gartner\\depatel windowslogin
	 * 
	 * @param password
	 *            - Password
	 * 
	 * @return - Map with Subject and From {Email No:- 3177 Receive Date:- Mon
	 *         Dec 18 13:14:36 EST 2017 Subject:- A Deal Hub Request has been
	 *         submitted by your team for TGA 0219 PROD TEST TONIGHT
	 *         1=crmpr@gartner.com}
	 * 
	 */
	public static Map<String, String> readEmail(String username, String password) {

		String host = "mail.gartner.com";
		String mailStoreType = "imaps";
		Map<String, String> output = new HashMap<String, String>();

		try {
			Properties props = new Properties();
			props.setProperty("mail.store.protocol", mailStoreType);
			props.setProperty("mail.imaps.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
			props.setProperty("mail.imaps.socketFactory.fallback", "false");
			props.setProperty("mail.imaps.port", "993");
			props.setProperty("mail.imaps.socketFactory.port", "993");

			Session session = Session.getDefaultInstance(props, null);

			Store store = session.getStore(mailStoreType);

			store.connect(host, username, password);
			Folder emailFolder = store.getFolder("INBOX");
			emailFolder.open(Folder.READ_ONLY);

			Message[] messages = emailFolder.getMessages();

			for (int i = messages.length - 1; (i > (messages.length - 6)) && (i > 0); i--) {
				Message message = messages[i];
				output.put("Email No:- " + i + " Receive Date:- " + message.getReceivedDate() + " Subject:- "
						+ message.getSubject(), message.getFrom()[0].toString());
			}
			emailFolder.close(false);
			store.close();
		} catch (NoSuchProviderException e) {
			e.printStackTrace();
		} catch (MessagingException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return output;
	}

	//

	public static void verifyEmailLast(String username, String password, String SR) throws MessagingException {

		String host = "mail.gartner.com";
		String mailStoreType = "imaps";
		String subject = "";
		Message message;
		try {
			Properties props = new Properties();
			props.setProperty("mail.store.protocol", mailStoreType);
			props.setProperty("mail.imaps.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
			props.setProperty("mail.imaps.socketFactory.fallback", "false");
			props.setProperty("mail.imaps.port", "993");
			props.setProperty("mail.imaps.socketFactory.port", "993");

			Session session = Session.getDefaultInstance(props, null);

			Store store = session.getStore(mailStoreType);

			store.connect(host, username, password);
			Folder emailFolder = store.getFolder("INBOX");
			emailFolder.open(Folder.READ_ONLY);

			Message[] messages = emailFolder.getMessages();

			message = messages[messages.length - 1];
			
			subject = message.getSubject();
			emailFolder.close(false);
			store.close();
		} catch (NoSuchProviderException e) {
			e.printStackTrace();
		} catch (MessagingException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(subject);
		if (subject.trim().equals("Client Connect SR with (Ref# " + SR+ ") has been assigned to you.")) {
			Log.printWorkflow("email verification passed");
		} else {
			Assert.fail("SR Details verification failed");
		}

	}

	//

	/**
	 * To send email with attachments
	 * 
	 * @param to
	 *            - Email Address of receiver
	 * 
	 * @param username
	 *            - gartner\\depatel windowslogin
	 * 
	 * @param password
	 *            - Password
	 * 
	 * @param attachment
	 *            - Path of attachment
	 * 
	 * @param subject
	 *            - Subject of Email
	 * 
	 * @param content
	 *            - Body of Email
	 * 
	 * @return - void
	 * 
	 */
	public static void sendEmail(String to, String username, String password, String attachment, String subject,
			String content) {

		String host = "extrelay.gartner.com";

		try {
			// Get system properties
			Properties props = System.getProperties();

			Authenticator authenticator = new Authenticator(username, password);
			props.put("mail.smtp.host", host);
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.submitter", authenticator.getPasswordAuthentication().getUserName());
			// Get session
			Session session = Session.getInstance(props, authenticator);
			session.setDebug(true);
			MimeMessage message = new MimeMessage(session);
			// message.setFrom(new InternetAddress(from));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
			message.setSubject(subject);

			Multipart multipart = new MimeMultipart();
			BodyPart messageBodyPart1 = new MimeBodyPart();
			messageBodyPart1.setText(content);
			multipart.addBodyPart(messageBodyPart1);

			if (!(attachment.equals("") || attachment.equals(null))) {
				MimeBodyPart messageBodyPart2 = new MimeBodyPart();
				DataSource source = new FileDataSource(attachment);
				messageBodyPart2.setDataHandler(new DataHandler(source));
				messageBodyPart2.setFileName(attachment.substring(attachment.lastIndexOf("\\") + 1));
				multipart.addBodyPart(messageBodyPart2);
			}

			message.setContent(multipart);

			Transport.send(message);
		}

		catch (MessagingException e) {
			e.toString();
		} catch (Exception mex) {
			mex.printStackTrace();
		}

	}

	static class Authenticator extends javax.mail.Authenticator {
		private PasswordAuthentication authentication;

		public Authenticator(String username, String password) {
			authentication = new PasswordAuthentication(username, password);
		}

		@Override
		protected PasswordAuthentication getPasswordAuthentication() {
			return authentication;
		}
	}

}