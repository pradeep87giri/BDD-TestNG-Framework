package pageObjectModel_Pages;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.time.DateUtils;
import org.openqa.selenium.By;

import baseClass.AppTest;
import utilities.elements.Field.Text;
import utilities.elements.Page;
import utilities.selenium.ExcelDataConfig;
import utilities.selenium.Log;

public class VerifyPage extends AppTest {
	/*Contains different methods for performing actions on verify page
	 * like adding bill to person, contract to person, correct estimated book date etc.*/

	public static void billToPerson() throws Exception {

		// Date class is used to find Current Date
		Date newDate = DateUtils.addMonths(new Date(), 1);
		// Changing date format in required format i.e yyyyMM.
		String estimatedDate = new SimpleDateFormat("yyyyMM").format(newDate);
		Log.printInfo("EstimatedBookDate is : " + estimatedDate);
		String estimatedBookDate = ExcelDataConfig.getParameterValue(sheetPath, "VerifyPage", "EstimatedBookDate");
		Text.setText(By.xpath(estimatedBookDate), "EstimatedBookDate", estimatedDate);

		String billTo = ExcelDataConfig.getParameterValueUsingColumnName(errorSheetPath, "ErrorDataSheet",

				"BillToPerson", "BillTo");
		String billToDropdown = ExcelDataConfig.getParameterValue(sheetPath, "VerifyPage", "BillToDropdown");
		/*When person give billTo person name in excel then excel value will be selected,
		 * else first first billToperson name will be selected and if billTo is blank then this error will be displayed
		 * No Bill To Person is present for the order.
		 * */
		if (billTo.isEmpty()) {
			String billToPersonDorpdown = ExcelDataConfig.getParameterValue(sheetPath, "VerifyPage",
					"billToPersonDorpdown");
			Page.clickButton(By.cssSelector(billToDropdown),

					"BillToDropdown");
			// Check for the blank BillTo Person drop down 
			if (Page.isPresentElement(By.xpath(billToPersonDorpdown), "BillToPerson") > 0) {
				Page.clickLink(By.xpath(billToPersonDorpdown), "BillToPerson");

			} else if (Page.isPresentElement(By.xpath(billToPersonDorpdown), "BillToPerson") < 0) {
				Log.printFail("No Bill To Person is present for the order.");
			}
		} else {
			Page.selectElement(By.cssSelector(billToDropdown), "BillToDropdown");
			Page.selectElement(By.xpath("//*[contains(text(),'" + billTo + "')]"), "BillToPerson");

		}

	}
}
