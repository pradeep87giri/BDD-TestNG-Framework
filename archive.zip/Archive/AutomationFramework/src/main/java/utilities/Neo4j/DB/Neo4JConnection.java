package utilities.Neo4j.DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import utilities.DB.DatabaseAccessException;
import utilities.selenium.Log;

public class Neo4JConnection {

	
	protected static Connection connection = null;

	/**
	 * This method can be used to connect to Neo4j database which uses http
	 * protocol and runs the query specified
	 * 
	 * @param host
	 *            Host name of the database
	 * @param port
	 *            Port used to connect to the database
	 * @param username
	 *            User name used to connect to database
	 * @param password
	 *            Password used to connect to database
	 * @param query
	 *            Query to be run on the database
	 * @return {@link ResultSet} containing the result of the database query
	 */
	protected static ResultSet queryDatabase(String host, String port, String username, String password, String query) {
		String url = "jdbc:neo4j:http://" + host + ":" + port;
		try {
			System.out.println(query);
			System.out.println(url);
			getConnection(url, username, password);
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(query);
			ResultSet resultSet = preparedStatement.executeQuery();
			return resultSet;
		} catch (SQLException e) {

			Log.printWorkflow(
					("Neo4j Database access error for queryDatabase() method for connection string - " + url));

			throw new DatabaseAccessException(e);
		}
	}

	/**
	 * Get Neo4j connection to the database
	 * 
	 * @param url
	 *            Connection URL containing host and port name
	 * @param username
	 *            User name used to connect to database
	 * @param password
	 *            Password used to connect to database
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	private static void getConnection(String url, String username, String password) {
		try {
			Class.forName("org.neo4j.jdbc.Driver");

			connection = DriverManager.getConnection(url, username, password);
			if (connection == null) {
				throw new DatabaseAccessException("Neo4j Connection is null");
			} else {
				Log.printWorkflow("Neo4j Connection successful using connection string " + url);
			}
		} catch (ClassNotFoundException e) {
			throw new DatabaseAccessException(e);
		} catch (SQLException e) {
			throw new DatabaseAccessException(e);
		}
	}

	/**
	 * Get Neo4j connection to the database
	 * 
	 * @param url
	 *            Connection URL containing host and port name
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	private static void getConnection(String url) {
		try {
			Class.forName("org.neo4j.jdbc.Driver");
			connection = DriverManager.getConnection(url);
			if (connection == null) {
				throw new DatabaseAccessException("Neo4j Connection is null");
			} else {
				Log.printWorkflow("Neo4j Connection successful using connection string " + url);
			}
		} catch (ClassNotFoundException e) {
			throw new DatabaseAccessException(e);
		} catch (SQLException e) {
			throw new DatabaseAccessException(e);
		}
	}

	/**
	 * Close connection to the database
	 * 
	 * @throws SQLException
	 */
	protected static void closeConnection() {
		try {
			connection.close();
			Log.printWorkflow("Neo4j Connection close successful");
		} catch (SQLException e) {
			Log.printWarning("Neo4j Connection close threw error");
			throw new DatabaseAccessException(e);
		}
	}

}
