package functional;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.apache.commons.io.FileDeleteStrategy;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class ReportLib extends MasterScriptMapping
{
public static File destFile,imgdestFile,imgCopyFile;
public static Path ImgPath;
public static Path Imgdestmailfile ;
public static String destination;
public static String TORECIPIENT,TOCCRECIPIENT,TOBCCRECIPIENT,fp1;
public static File TempFolder,ImgFolder;
public static  ZipOutputStream out;
public static File outFolder;
public static Path latestFilePath,imglatestFilePath ;
public static String  Mailusername , Mailpassword;

public static String CaptureScreenshot(RemoteWebDriver driver, String ScreenShotName) throws IOException
{
	try
	{
	TakesScreenshot ts = (TakesScreenshot) driver;
	File source = ts.getScreenshotAs(OutputType.FILE);
	destination = "./ReportFolderScreenshot/"+sSuiteID.concat(sTestID).concat(sPageID).concat(strMethod).concat(sTCIteration).concat(timeStamp)+".png";
	System.out.println("Report Path 3 " +destination);
	File dest = new File (destination);
	System.out.println("DEST" +dest);
	FileUtils.copyFile(source, dest);
	dest.setWritable(true);
	}
	catch(Exception e)
	{
		 logger.log(LogStatus.FATAL,"<span style='color:steelblue;font-weight:bold;'>Exception Occured - Taking Screenshot : </span> " +e);
	}
	return destination;
}
//Copy files from Report Folder to latest Report Folder to mail
public static void CreateFolder()
{
	try
	{
		//fetching latest HTML report to mail
		Path filepath = Paths.get(System.getProperty("user.dir")+"/ReportFolder");
		System.out.println("Report Path 4 " +filepath);
		DirectoryStream<Path> dirStream = Files.newDirectoryStream(filepath);
		long newest = 0L;
		for(Path path : dirStream) 
		{		
			BasicFileAttributes attr = Files.readAttributes(path, BasicFileAttributes.class);			
	    	long createTime = attr.creationTime().toMillis();
	    	if(createTime > newest)
	    	{
	    		newest = createTime;
	    	}
	    	System.out.println("PATH -----------" +path);
	    	latestFilePath = path;
		}
		System.out.println("The newest file is: " + latestFilePath);
    	ImgPath = Paths.get(System.getProperty("user.dir")+"/ReportFolder"+"/Gartner_logo.png");
    	Imgdestmailfile = Paths.get(latestFilePath + "/" +"Gartner_logo.png");
    	System.out.println("The Image file is: " + ImgPath);
		Files.copy(ImgPath, Imgdestmailfile, StandardCopyOption.COPY_ATTRIBUTES);		
		System.out.println("The newest Image file is: " + latestFilePath.getFileName());
		Thread.sleep(2000);
	}
	catch(Exception e)
	{
		logger.log(LogStatus.FATAL, "<span style='color:steelblue	;font-weight:bold;'>Exception Occured While Fetching Latest File In Report Folder : </span>" +e);
	}
// fetch latest  image folder to add to folder to mail
	try
	{
		Path imgfilepath = Paths.get(System.getProperty("user.dir")+"/ReportFolderScreenshot");
		System.out.println("Report Path 4 " +imgfilepath);
		DirectoryStream<Path> imgdirStream = Files.newDirectoryStream(imgfilepath);
		for(Path path : imgdirStream) 
		{	
			System.out.println("PATH==" +path);
			//Copy Image folder to the SuitewithTimeStampFolder in ReportFolder			
			try
			{	
				ImgFolder = new File(System.getProperty("user.dir")+"/ReportFolder/"+sSuiteName.concat("-").concat(timeStamp)+"/ReportFolderScreenshot");		
				imgCopyFile = new File(path.toString());
				File dir = imgCopyFile;	
				FileUtils.copyFileToDirectory(dir, ImgFolder, true);
				Thread.sleep(1000);
			}
			catch(Exception e)
			{
				logger.log(LogStatus.FATAL, "<span style='color:steelblue	;font-weight:bold;'>Exception Occured While Adding Snapshot Folder in Report Folder : </span>" +e);
			}
		}
		ImgFolder.setWritable(true);
	}
	catch(Exception e)
	{
		logger.log(LogStatus.FATAL, "<span style='color:steelblue	;font-weight:bold;'>Exception Occured While Fetching Snapshot Folder in Report Folder Screenshot : </span>" +e);
	}
//zip ImageFolder
	try
	{
		imgdestFile = new File(ImgFolder.getPath().toString());
		File inFolder = imgdestFile;
		System.out.println("INFOLDER IMAGE " +inFolder);
		outFolder=new File(imgdestFile+".zip");
		System.out.println("OUTFOLDER IMAAGE" +outFolder);
		out = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(outFolder)));
		BufferedInputStream in = null;
		byte[] data = new byte[1024];
		String files[] = inFolder.list();
		System.out.println("-------------"+files);
		imgdestFile.setWritable(true);
		for (int i=0; i<files.length; i++)
		{
			in = new BufferedInputStream(new FileInputStream(inFolder.getPath() + "/" + files[i]), 1000);                  
			out.putNextEntry(new ZipEntry(files[i])); 
			int count;
			while((count = in.read(data,0,1000)) != -1)
			{
				out.write(data, 0, count);
			}
			out.closeEntry();
		}
		in.close();	
		out.flush();
		out.close();
		Thread.sleep(2000);
		imgdestFile.setWritable(true);
		//Delete the ReportFolderScreenshot to keep the Zip
		File dir = imgdestFile;
		System.out.println("Can write dir "+dir.canWrite());
		if (dir.isDirectory())
		{
			File[] filesimg = dir.listFiles();
			if (filesimg != null && files.length > 0)
			{
				for (File aFile : filesimg) 
				{
					System.gc();
					Thread.sleep(2000);
					FileDeleteStrategy.FORCE.delete(aFile);
					System.out.println("delet file" +aFile);
				}
			}
			dir.delete();
			System.out.println("delet" +dir);
		} 
		else 
		{
			dir.delete();
		}
	}
	catch(Exception e)
	{
		logger.log(LogStatus.FATAL, "<span style='color:steelblue	;font-weight:bold;'>Exception Occured While Zipping Snapshot Folder To Mail : </span>" +e);
		e.printStackTrace();
	}  
//Zip the folder	
	try
	{
		destFile = 	new File(latestFilePath.toString());
		File inFolder = destFile;
		System.out.println("INFOLDER" +inFolder);
		outFolder=new File(destFile+".zip");
		System.out.println("OUTFOLDER" +outFolder);
		out = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(outFolder)));
		fp1 = outFolder.getName();
		BufferedInputStream in = null;
		byte[] data = new byte[1024];
		String files[] = inFolder.list();
		System.out.println("-------------"+files);
		inFolder.setWritable(true);
		for (int i=0; i<files.length; i++)
		{
			in = new BufferedInputStream(new FileInputStream(inFolder.getPath() + "/" + files[i]), 1000);                  
			out.putNextEntry(new ZipEntry(files[i])); 
			int count;
			while((count = in.read(data,0,1000)) != -1)
			{
				out.write(data, 0, count);
			}
			out.closeEntry();
		}
		out.flush();
		out.close(); 
		in.close();
	}
	catch(Exception e)
	{
		logger.log(LogStatus.FATAL, "<span style='color:steelblue;font-weight:bold;'>Exception Occured While Zipping Folder To Mail : </span>" +e);
		e.printStackTrace();
	}  
}
//Reading mail XML to send the mail 
public static ExtentTest ReadMailXml()
{
	try 
	{
		String filepath = "./mailConfig.xml";
		File fXmlFile = new File(filepath);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(fXmlFile);
		doc.getDocumentElement().normalize();
		System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
		NodeList nList = doc.getElementsByTagName("mailDetail");
		for (int temp = 0; temp < nList.getLength(); temp++) 
		{
			Node nNode = nList.item(temp);
			System.out.println("\nCurrent Element :" + nNode.getNodeName());
			if (nNode.getNodeType() == Node.ELEMENT_NODE) 
			{
				Element eElement = (Element) nNode;		
				TORECIPIENT = eElement.getElementsByTagName("toRecipient").item(0).getTextContent();
				TOCCRECIPIENT = eElement.getElementsByTagName("ccRecipient").item(0).getTextContent();
				TOBCCRECIPIENT = eElement.getElementsByTagName("bccRecipient").item(0).getTextContent();
			}
		}
	} 
	catch (Exception e) 
	{
		logger.log(LogStatus.FATAL, "<span style='color:steelblue;font-weight:bold;'>Exception Occured While Reading mailConfig XML : </span>" +e);
	}
	return logger;
}
//Send Mail From Outlook
public static ExtentTest SendMail()
{
	try
	{
		Properties props = new Properties();
		props.load(new FileInputStream("./ResourceData.properties"));
		Mailusername = props.getProperty("username");
		Mailpassword= props.getProperty("password");
		props.put("mail.smtp.user", Mailusername);
		props.put("mail.smtp.host", "extrelay.gartner.com");
		props.put("mail.smtp.port", "25");
		props.put("mail.debug", "true");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.EnableSSL.enable", "true");
		props.setProperty("mail.smtp.port", "25");
		props.setProperty("mail.smtp.socketFactory.port", "25");
		Session session = Session.getInstance(props,new javax.mail.Authenticator() 
		{
			@Override
			protected PasswordAuthentication getPasswordAuthentication() 
			{
				return new PasswordAuthentication(Mailusername, Mailpassword);
			}
		});	
		try 
		{
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(Mailusername));
			System.out.println(Mailusername);
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(TORECIPIENT));
			message.addRecipients(Message.RecipientType.CC, InternetAddress.parse(TOCCRECIPIENT));
			message.addRecipients(Message.RecipientType.BCC, InternetAddress.parse(TOBCCRECIPIENT));
			message.setSubject("Emailing : F.A.S.T Report");
			BodyPart messageBodyPart = new MimeBodyPart();
			Multipart multipart = new MimeMultipart();
			BodyPart htmlPart = new MimeBodyPart();
			htmlPart.setContent("<html><body>The report is delivered by CBS_PeopleTech_QA ( sender of the mail) , the file comprehends the latest execution for <b>Automated Testing triggered </b>from your system.<br>In case of any queries contact the Team.</body></html>", "text/html");
			DataSource source = new FileDataSource(outFolder);
			messageBodyPart.setDataHandler(new DataHandler(source));
			messageBodyPart.setFileName(fp1);
			multipart.addBodyPart(messageBodyPart);
			multipart.addBodyPart(htmlPart);
			message.setContent(multipart);
			Transport.send(message);
			logger.log(LogStatus.INFO, "<span style='color:steelblue;font-weight:bold;'>Mail has been sent</span>");
		} 
		catch (Exception e) 
		{
			logger.log(LogStatus.FATAL, "<span style='color:steelblue;font-weight:bold;'>Exception Occured While Authenticating Mail : </span>" +e);
		}    
	}	
	catch(Exception e)
	{
	logger.log(LogStatus.FATAL, "<span style='color:steelblue;font-weight:bold;'>Exception Occured While Sending Mail : </span>" +e);
	}
	return logger;
}
//Deletes All The Reports and Zip Folder from Report Folder
public static boolean removeDir()
{
	try
	{
		File dir = destFile;
		TempFolder = new File(System.getProperty("user.dir")+"/TempReportFolder/"+sSuiteName.concat("-").concat(timeStamp));
		File dirZip = outFolder;
		if (dir.isDirectory())
		{
			File[] files = dir.listFiles();
			if (files != null && files.length > 0)
			{
				for (File aFile : files) 
				{
					FileUtils.copyFileToDirectory(aFile, TempFolder, true);
					System.gc();
					Thread.sleep(2000);
					FileDeleteStrategy.FORCE.delete(aFile);
					System.out.println("delet file" +aFile);
				}
			}
			dir.delete();
			System.out.println("delet" +dir);
		} 
		else 
		{
			dir.delete();
		}
		if (dirZip.isDirectory())
		{
			File[] zipfiles = dirZip.listFiles();
			if (zipfiles != null && zipfiles.length > 0)
			{
				for (File aFile : zipfiles) 
				{
					System.gc();
					Thread.sleep(2000);
					FileDeleteStrategy.FORCE.delete(aFile);
					System.out.println("delete ZIP file" +aFile);
				}
			}
			dirZip.delete();
			System.out.println("delete ZIP" +dirZip);
		} 
		else 
		{
			dirZip.delete();
		}
	}
	catch(Exception e)
	{
		logger.log(LogStatus.FATAL, "<span style='color:steelblue;font-weight:bold;'>Exception Occured While Deleting Folder : </span>" +e);
	}
	return true;
}
//Cleans Report Folder and Report Folder Screenshot before starting any function
public static boolean CleanDir()
{
	try
	{
		Path filepath = Paths.get(System.getProperty("user.dir")+"/ReportFolder");
		DirectoryStream<Path> dirStream = Files.newDirectoryStream(filepath);
		for(Path path : dirStream) 
		{	
			if(path.toString().contains(".png"))
			{}
			else
			{
				destFile = 	new File(path.toString());
				File dir = destFile;
				if (dir.isDirectory())
				{
					File[] files = dir.listFiles();
					if (files != null && files.length > 0)
					{
						for (File aFile : files) 
						{
							System.gc();
							//FileUtils.copyFileToDirectory(aFile, TempFolder, true);
							FileDeleteStrategy.FORCE.delete(aFile);
							System.out.println("delet file" +aFile);
						}
					}
					dir.delete();
					System.out.println("delet" +dir);
				} 
				else 
				{
					dir.delete();
				}
			}
		}
	}
	catch(Exception e)
	{
		logger.log(LogStatus.FATAL, "<span style='color:steelblue;font-weight:bold;'>Exception Occured While Cleaning Folder : </span>" +e);
	}
	try
	{
		Path filepath = Paths.get(System.getProperty("user.dir")+"/ReportFolderScreenshot");
		DirectoryStream<Path> dirStream = Files.newDirectoryStream(filepath);
		for(Path path : dirStream) 
		{	
			destFile = 	new File(path.toString());
			File dir = destFile;
			if (dir.isDirectory())
			{
				File[] files = dir.listFiles();
				if (files != null && files.length > 0)
				{
					for (File aFile : files) 
					{
						System.gc();
						FileDeleteStrategy.FORCE.delete(aFile);
						System.out.println("delet file" +aFile);
					}
				}
				dir.delete();
				System.out.println("delet" +dir);
			} 
			else 
			{
				dir.delete();
			}
		}
	}
	catch(Exception e)
	{
		logger.log(LogStatus.FATAL, "<span style='color:steelblue;font-weight:bold;'>Exception Occured While Cleaning Folder : </span>" +e);
	}
	return true;
}
}