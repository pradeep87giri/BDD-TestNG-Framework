
package utilities.elements;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.google.common.base.Function;
import com.relevantcodes.extentreports.LogStatus;

import utilities.selenium.Driver;
import utilities.selenium.Log;

/**
 * A library of click functions that can be performed on any button in OUI. There are hard coded
 * buttons for those that are seen multiple times throughout the site. Methods for buttons that are
 * special cases are also included.
 */
public class Button
{
	/**
	 * Class used for clicking the menu button on an OUI page, the method contained is used to click
	 * the button
	 */
	public static class Menu
	{
		/**
		 * Clicks a selected menu button on an OUI page
		 * 
		 * @param index The index of the button on the page
		 */
		public static void click(int index)
		{
			Log.printInfo("Clicking 'Menu' button");

			Page.findElements(By.cssSelector("button[title*='Menu'][type='button']"), "'Menu' button").get(index).click();
		}

		/**
		 * Class used for clicking the save record link on an OUI page after clicking the menu
		 * button, the method contained is used to click the button
		 * 
		 */
		public static class SaveRecord
		{
			/**
			 * Clicks the save record link from a menu list. Used after clicking on menu
			 */
			public static void click()
			{
				Log.printInfo("Clicking 'Save Record [Ctrl+S]'");

				Page.findElement(By.linkText("Save Record [Ctrl+S]"), "'Save Record [Ctrl+S]' link").click();
			}
		}

		/**
		 * Class used for clicking the delete record button on an OUI page after clciking the menu
		 * button, the method contained is used to click the button
		 */
		public static class DeleteRecord
		{
			/**
			 * Clicks the delete record link from a menu list. Used after clicking on menu
			 */
			public static void click()
			{
				Log.printInfo("Clicking 'Delete Record [Ctrl+D]'");

				Page.findElement(By.linkText("Delete Record [Ctrl+D]"), "'Delete Record [Ctrl+D]' link").click();
			}
		}

		/**
		 * Class used for clicking the undo record button on an OUI page after clicking the menu
		 * button, the method contained is used to click the button
		 */
		public static class UndoRecord
		{
			/**
			 * Clicks the undo record link from a menu list. Used after clicking on menu
			 */
			public static void click()
			{
				Log.printInfo("Clicking 'Undo Record [Ctrl+U]'");

				Page.findElement(By.linkText("Undo Record [Ctrl+U]"), "'Undo Record [Ctrl+U]' link").click();
			}
		}
	}

	/**
	 * Class used for clicking the new button on an OUI page, the method contained is used to click
	 * the button
	 */
	public static class New
	{
		/**
		 * Clicks a selected new button on an OUI page
		 * 
		 * @param index The index of the button on the page
		 */
		public static void click(int index)
		{
			Log.printInfo("Clicking 'New' button");

			Page.findElements(By.cssSelector("button[title*='New'][type='button']"), "'New' button").get(index).click();
		}
	}

	/**
	 * Class used for clicking the query record button on an OUI page, the method contained is used
	 * to click the button
	 */
	public static class Query
	{
		/**
		 * Clicks a selected Query button on an OUI page
		 * 
		 * @param index The index of the button on the page
		 */
		public static void click(int index)
		{
			Log.printInfo("Clicking 'Query' button");

			Page.findElements(By.cssSelector("button[title$=':Query'][type='button']"), "'Query' button").get(index).click();
		}
	}

	/**
	 * Class used for clicking the go button on an OUI page, the method contained is used to click
	 * the button
	 */
	public static class Go
	{
		/**
		 * Clicks a selected Go button on an OUI page
		 * 
		 * @param index The index of the button on the page
		 */
		public static void click(int index)
		{
			Log.printInfo("Clicking 'Go' button");

			Page.findElements(By.cssSelector("button[title*='Go'][type='button']"), "'Go' button").get(index).click();
		}
	}

	/**
	 * Class used for clicking the delete button on an OUI page, the method contained is used to
	 * click the button
	 */
	public static class Delete
	{
		/**
		 * Clicks a selected Delete button on an OUI page
		 * 
		 * @param index The index of the button on the page
		 */
		public static void click(int index)
		{
			Log.printInfo("Clicking 'Delete' button");

			Page.findElements(By.cssSelector("button[title*='Delete'][type='button']"), "'Delete' button").get(index).click();
		}
	}

	/**
	 * Class used for clicking the cancel button on an OUI page, the method contained is used to
	 * click the button
	 */
	public static class Cancel
	{
		/**
		 * Clicks a selected Cancel button on an OUI page
		 * 
		 * @param index The index of the button on the page
		 */
		public static void click(int index)
		{
			Log.printInfo("Clicking 'Cancel' button");

			Page.findElements(By.cssSelector("button[title*='Cancel'][type='button']"), "'Cancel' button").get(index).click();
		}
	}

	/**
	 * Class used for clicking the OK button on an OUI page, the method contained is used to click
	 * the button
	 */
	public static class OK
	{
		/**
		 * Clicks a selected OK button on an OUI page
		 * 
		 * @param index The index of the button on the page
		 */
		public static void click(int index)
		{
			Log.printInfo("Clicking 'OK' button");

			Page.findElements(By.cssSelector("button[title*='OK'][type='button']"), "'OK' button").get(index).click();
		}
	}

	/**
	 * Click a button that is special to the current page. Not found in other areas of the site.
	 * 
	 * @param buttonName The text on the button
	 * @param index Default is 0 if there are no more of the same button.
	 */
	public static void click(String buttonName, int index)
	{
		Log.printInfo("Clicking '" + buttonName + "' button");

		Page.findElements(By.cssSelector("button[title*='" + buttonName + "'][type='button']"), "'" + buttonName + "' button").get(index).click();
	}

	/**
	 * Click a button that doesn't follow the cssSelector of the other button classes.
	 * 
	 * @param selector by Unique selector for a button. Ex)
	 *            By.cssSelector("button[id='exampleID']").
	 * @param buttonName The text on the button
	 */
	public static void click(By selector, String buttonName)
	{
		Log.printInfo("Clicking '" + buttonName + "' button");
		
		Driver.waitForAjaxToComplete();
		
		WebElement Button = Page.findElement(selector, "'" + buttonName + "' button");
		
		for (int seconds = 0;; seconds++)
		{
			new WebDriverWait(Driver.Instance, Driver.timeOut).until(ExpectedConditions.elementToBeClickable(selector));
			
			Driver.pause(.5);
			
			try
			{
				Button.click();
				Driver.waitForAjaxToComplete();
				break;
			}
			catch (UnhandledAlertException e1)
			{
				throw e1;
			}
			catch (ElementNotVisibleException e2)
			{
				Actions build = new Actions(Driver.Instance);
				build.moveToElement(Button, 0, 0).click().build().perform();
				Driver.waitForAjaxToComplete();
				break;
			}
			catch (Exception e3) {/* ignore */}
			
			if (seconds > Driver.timeOut)
				Assert.fail("Unable to click '" + buttonName + "' button");
			
			Driver.pause(.5);
		}
	}
	
	/**
	 * Click a button that doesn't follow the cssSelector of the other button classes.
	 * 
	 * @param selector by Unique selector for a button. Ex)
	 *            By.cssSelector("button[id='exampleID']").
	 * @param buttonName The text on the button
	 * @param index Default is 0 if there are no more of the same button.
	 */
	public static void click(By selector, String buttonName, int index)
	{
		Log.printInfo("Clicking '" + buttonName + "' button");

		Page.findElements(selector, "'" + buttonName + "' button").get(index).click();
	}



//public static class Wait
//{
//	/**
//	 * Clicks a selected OK button on an OUI page
//	 * 
//	 * @param index The index of the button on the page
//	 */
//	public static void fluentWait(By locator, String fieldName)
//	{
//		Log.printInfo("Fluent Wait on " + fieldName);
//		WebElement ele;
//			Wait<WebDriver> wait = new FluentWait<WebDriver>((WebDriver) driver)
//					.withTimeout(180, TimeUnit.SECONDS).pollingEvery(3, TimeUnit.SECONDS)
//					.ignoring(NoSuchElementException.class);
//			WebElement element = wait.until(new Function<WebDriver, WebElement>() {
//
//				public WebElement apply(WebDriver driver) {
//					ele = Page.findElement(locator,fieldName);
//
//					if (ele.isDisplayed()) {
//						return ele;
//					} else {
//						return null;
//					}
//				}
//			});
//					
//		}
//	}
}

