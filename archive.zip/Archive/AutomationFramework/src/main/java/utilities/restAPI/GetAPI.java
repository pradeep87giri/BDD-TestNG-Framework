package utilities.restAPI;

import static io.restassured.RestAssured.*;


import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import utilities.parameters.ParameterTable;
import utilities.selenium.Log;



public class GetAPI {

	/*public static Response getDocumentAPIResponse(RequestSpecification reqSpec,ResponseSpecification respSpec){
	
	
	
	Response rsp=given().spec(reqSpec).log().all()
			     .when().get(ResourcesAPI.getDocuments())
			     .then().spec(respSpec).log().all()
		          .extract().response();
	;
	
	return rsp;
	
	}


public static Response getValueStatementAPIResponse(RequestSpecification reqSpec,ResponseSpecification respSpec){
	
	
	
	Response rsp=given().spec(reqSpec).log().all()
			     .when().get(ResourcesAPI.getValueStatements())
			     .then().spec(respSpec).log().all()
		          .extract().response();
	;
	
	return rsp;
	
	}*/
public static void getResponseCode(String url) {
	
	Response resp = get(url);
	if(resp.getStatusCode()==200) {
		Log.printInfo("API is working fine.");
	} else {
		Log.printInfo("API is not working fine.");
	}
}

public static void getResponseCode(String url, String paramname, Object paramvalue) {
	
	Response resp = given().param(paramname, paramvalue)
			.when().get(url);
	if(resp.getStatusCode()==200) {
		Log.printInfo("API is working fine.");
	} else {
		Log.printInfo("API is not working fine.");
	}
					
}

public static void getResponseCode(String url, String paramname1, Object paramvalue1,String paramname2, Object paramvalue2) {
	
	Response resp = given().param(paramname1, paramvalue1).param(paramname2, paramvalue2)
			.when().get(url);
	if(resp.getStatusCode()==200) {
		Log.printInfo("API is working fine.");
	} else {
		Log.printInfo("API is not working fine.");
	}
					
}

public static void fieldNameUsingJsonPath(String url, String paramname1, Object paramvalue1,String paramname2, Object paramvalue2, String fieldName,String fieldPath) {
	//Use link : jsonpath.curiousconcept.com to find json path.
	try {
		Response resp = given().param(paramname1, paramvalue1).param(paramname2, paramvalue2)
			.when().get(url);
	
	String fieldvalue = resp.then().contentType(ContentType.JSON).extract().path(fieldPath);
	
	//Log.printInfo(fieldName + " value is  : " + fieldvalue);
	ParameterTable.add(fieldName, fieldvalue);
} catch (Exception e) {
	Log.printInfo("Get request was not successful for : " + fieldName);
}
}


}