package functional;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.testng.TestNG;

public class MasterScriptMappingDriver 
{
	static JFrame frame = new JFrame("JOptionPane showMessageDialog example");
public static void main(String[] args) 
{
	Thread t = new Thread(new Runnable()
	{
	public void run()
	{			
		JOptionPane.showMessageDialog(frame,"Starting Exceution ","F.A.S.T",JOptionPane.PLAIN_MESSAGE);	
	}
	});
	t.start();
	//Create object of TestNG Class
	TestNG runner=new TestNG();
	// Create a list of String 
	List<String> suitefiles=new ArrayList<String>();
	// Add xml file which you have to execute
	suitefiles.add(System.getProperty("user.dir")+"\\testng.xml");
	// now set xml file for execution
	runner.setTestSuites(suitefiles);
	// finally execute the runner using run method
	runner.run();
}
}