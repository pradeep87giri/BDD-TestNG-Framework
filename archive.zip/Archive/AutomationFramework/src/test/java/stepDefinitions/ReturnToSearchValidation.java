package stepDefinitions;

import cucumber.api.java.en.Then;
import pageObjectModel_Pages.ATOPage;

public class ReturnToSearchValidation {

	@Then("^Click Return To Search and Validate$")
	public void click_Return_To_Search_and_Validate() throws Throwable {
	   ATOPage.clickReturnToSearch();
	   
	}
	
}
