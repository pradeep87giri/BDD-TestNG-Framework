package testRunners;

import baseClass.AppTest;
import cucumber.api.CucumberOptions;

@CucumberOptions(features = "src/test/resources/Feature/OrderWordDocValidation.feature",
tags = {"@SmokeTest"},
glue={"stepDefinitions"},
format = { "pretty",
"html:target/site/OrderWordDocValidation",
"rerun:target/rerun.txt",
"json:target/OrderWordDocValidation.json" },dryRun=false,monochrome = true)
public class OrderWordDocValidation extends AppTest {

}
