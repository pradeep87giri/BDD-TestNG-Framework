package browserGrid;

import java.net.MalformedURLException;
import java.net.URL;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

//The class will add all the browser capabilities required to run different browsers.
public class browserCapabilities
{
public static RemoteWebDriver driver;
//
public static RemoteWebDriver getDriver(String browser) throws MalformedURLException 
{
	return new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), getBrowserCapabilities(browser));
}
private static DesiredCapabilities getBrowserCapabilities(String browserType) 
{	
	
		if(browserType.equalsIgnoreCase("Firefox"))
		{
			System.out.println("Opening firefox driver");
			return DesiredCapabilities.firefox();
		}
		if(browserType.equalsIgnoreCase("chrome"))
		{
			System.out.println("Opening chrome driver");
			return DesiredCapabilities.chrome();
		}
		if(browserType.equalsIgnoreCase("InternetExplorer"))
		{
			System.out.println("Opening IE driver");
			return DesiredCapabilities.internetExplorer();
		}
		else
		{
			System.out.println("browser : " + browserType + " is invalid, Launching chrome as browser of choice..");
			return DesiredCapabilities.chrome();
		}
}
}
