package functional;
import java.io.File;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import browserGrid.browserCapabilities;

public class MasterScriptMapping extends MasterScriptMappingDriver
{
static DBConnection dbc = new DBConnection();
static Connection connection = dbc.CreateConnection();
public static String sTestID,sPageID,sSuiteID,sSuiteName,strMethod,sqlPage,sqlPageDataSheet,sLoadActionTestData,sBrowser,sPageDataSheetName,sTCIteration,sPageOccID,sOnErrorFlag,sTestDataAvl,sScreenshot;
public static HashMap<String, String> oGlobalHashMap = new HashMap<String, String>();
public static boolean blnDataNotFound;
public static String Param1 = "";
public static String Param2 = "";
public static String Param3 = "";
public static String Param4 = "";
public static String Param5 = "";
public static String strChild = "";
public static String strParent = "";
public static String sKeywordStatus = "";
public static String sActualResult= "";
public static int iExitScenarioFlag;
public static int iBreakflagSuite = 1;
public static RemoteWebDriver driver;
public static WebDriverWait dynamicWait;
public static ExtentReports reports;
public static ExtentTest logger;
public static String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss.SSS").format(new Date());

//Cleans All Directories 
@BeforeTest
public void BeforeMasterSuitetestMap()
{
	ReportLib.CleanDir();
}
//Driver Functionality of FW
@Test
public static void MasterSuiteTestMap() throws InterruptedException
{
	KeywordRepository  objKC = new KeywordRepository();  
	Method m[] = objKC.getClass().getDeclaredMethods();	
	try
	{
		System.out.println("================BEGIN TEST CLASS================ ");
		Statement stMasterSuiteTestMapBrowser = connection.createStatement();//takes all suites set as Y ordered by seq no
		ResultSet rsMasterSuiteTestMapBrowser = stMasterSuiteTestMapBrowser.executeQuery("Select * from MasterSuiteTestMapBrowser where UCASE(EXECUTION_FLAG) = 'Y'  Order by EXECUTION_SEQNO");
		while (rsMasterSuiteTestMapBrowser.next())
		{
			try
			{
				sSuiteName = rsMasterSuiteTestMapBrowser.getString("SUITE_NAME");
				reports = new ExtentReports(System.getProperty("user.dir")+"/ReportFolder/"+sSuiteName.concat("-").concat(timeStamp)+"/"+"Report_"+sSuiteName.concat(".html"));
   	 			oGlobalHashMap.put("sBrowserType", rsMasterSuiteTestMapBrowser.getString("BROWSER_TYPE"));
		   	 	sBrowser = oGlobalHashMap.get("sBrowserType");
		   	 	System.out.println("choosing browser" +sBrowser);
		   	 	System.out.println("SUITE " +sSuiteName);
		   	 	//set up driver and call the package class browserCapabilities
		   	 	driver = browserCapabilities.getDriver(sBrowser); 
		   	 	Statement stMasterSuiteTestMap = connection.createStatement();//takes all suites set as Y ordered by seq no
		   	 	ResultSet rsMasterSuiteTestMap = stMasterSuiteTestMap.executeQuery("Select * from MasterSuiteTestMap where SUITE_NAME = '"  + sSuiteName  + "' And  UCASE(EXECUTION_FLAG) = 'Y' Order by EXECUTION_SEQNO");
		   	 	while (rsMasterSuiteTestMap.next()) 
		   	 	{
		   	 		oGlobalHashMap.put("sCurrentTestID", rsMasterSuiteTestMap.getString("TEST_ID")); 	 
		   	 		oGlobalHashMap.put("sCurrentTestIteration", rsMasterSuiteTestMap.getString("TEST_ITERATION"));
		   	 		sTestID = oGlobalHashMap.get("sCurrentTestID"); 
	 				sTCIteration = oGlobalHashMap.get("sCurrentTestIteration");
		   	 		//start Test
	   	 			logger = reports.startTest(sTestID.concat("_").concat(sTCIteration)); 
		   	 		try
		   	 		{
		   	 			oGlobalHashMap.put("sCurrentSuiteName", rsMasterSuiteTestMap.getString("SUITE_NAME")); 
		   	 			sSuiteID = oGlobalHashMap.get("sCurrentSuiteName");
		   	 			System.out.println("Report Path 1 " +reports.toString());	
		   	 			dynamicWait = new WebDriverWait(driver, 25);
		   	 			logger.log(LogStatus.INFO,"<span style='color:steelblue'>Bowser Name : </span>" +sBrowser);	
		   	 			logger.log(LogStatus.INFO,"<span style='color:steelblue'>Suite Name :  </span>" +sSuiteID);					
		   	 			System.out.println("TestCaseID " +oGlobalHashMap.get("sCurrentTestID"));		
		   	 			System.out.println("-----------------------------------------------------");
		   	 			System.out.println("SuiteName " +oGlobalHashMap.get("sCurrentSuiteName"));
   	 					System.out.println("TestCaseIteration " +sTCIteration);
   	 					logger.log(LogStatus.INFO,"<span style='color:steelblue'>TestCase ID : </span>" +oGlobalHashMap.get("sCurrentTestID"));
	 					oGlobalHashMap.put("sCurrentTCDescription" , rsMasterSuiteTestMap.getString("TEST_DESCRIPTION"));
	 					logger.log(LogStatus.INFO,"<span style='color:steelblue'>TestCase Iteration : </span> " +sTCIteration +"<span style='color:steelblue;'> TestCase Description : </span>"+oGlobalHashMap.get("sCurrentTCDescription"));
	 					System.out.println("TestCaseDescription " +oGlobalHashMap.get("sCurrentTCDescription"));
		   	 			Statement stMasterTestMap = connection.createStatement();	            
		   	 			ResultSet rsMasterTestMap = stMasterTestMap.executeQuery("Select * from MasterTestMap where TEST_ID = '" + sTestID  + "' And UCASE(EXECUTION_FLAG) = 'Y' Order by PAGE_OCCID");
		   	 			while (rsMasterTestMap.next()) 
		   	 			{
		   	 				try
		   	 				{
		   	 					sPageID = rsMasterTestMap.getString("PAGE_ID");
		   	 					oGlobalHashMap.put("sCurrentActionID", sPageID);
		   	 					oGlobalHashMap.put("sCurrentActionDataRowID", rsMasterTestMap.getString("PAGE_OCCID"));
		   	 					System.out.println("PAGE OCCURENCE ID ---------->" +	oGlobalHashMap.get("sCurrentActionDataRowID"));
		   	 					sPageOccID = oGlobalHashMap.get("sCurrentActionDataRowID");
		   	 					Statement stPageDataSheetMap = connection.createStatement();
		   	 					ResultSet rsPageDataSheetMap = stPageDataSheetMap.executeQuery("Select * from PageDataSheetMap where PAGE_ID = '" + sPageID+ "'");
		   	 					while (rsPageDataSheetMap.next()) 
		   	 					{
		   	 						try
		   	 						{
		   	 							oGlobalHashMap.put("sCurrentPageName", rsPageDataSheetMap.getString("PAGE_ID"));
		   	 							oGlobalHashMap.put("sCurrentPageDesc", rsPageDataSheetMap.getString("PAGE_DESCRIPTION"));
		   	 							oGlobalHashMap.put("sCurrentPageDataSheetName", rsPageDataSheetMap.getString("PAGE_DATASHEETNAME"));
		   	 							System.out.println("CurrentPageName " +oGlobalHashMap.get("sCurrentPageName"));
		   	 							System.out.println("CurrentPageDesc " +oGlobalHashMap.get("sCurrentPageDesc"));
		   	 							System.out.println("CurrentDatasheetName " +oGlobalHashMap.get("sCurrentPageDataSheetName"));
		   	 							sPageDataSheetName = oGlobalHashMap.get("sCurrentPageDataSheetName");
		   	 							logger.log(LogStatus.INFO,"<span style='color:steelblue;font-weight:bold;font-size:17px''>Page ID : </span>" +oGlobalHashMap.get("sCurrentPageName"));
		   	 							logger.log(LogStatus.INFO,"<span style='color:steelblue;font-weight:bold;font-size:17px'>Page DataSheet : </span>" +sPageDataSheetName);
		   	 							logger.log(LogStatus.INFO,"<span style='color:steelblue;'>Page OccurenceID : </span>" +oGlobalHashMap.get("sCurrentActionDataRowID")+"<span style='color:steelblue;'> Page Description : </span>" +oGlobalHashMap.get("sCurrentPageDesc"));
		   	 						}
		   	 						catch(Exception e)
		   	 						{
		   	 							logger.log(LogStatus.FATAL,"<span style='color:steelblue;font-weight:bold'>Exception Occured - PageDataSheetMap  : </span>" +e);
		   	 							System.out.println("Exception Occured : PageDataSheetMap ");
		   	 							e.printStackTrace();
		   	 						}
		   	 					}
		   	 					stPageDataSheetMap.close();
		   	 					rsPageDataSheetMap.close();
		   	 					sTestDataAvl = MasterScriptLib.PageDataSheet();
		   	 					iExitScenarioFlag = 0;
		   	 					if (sTestDataAvl.contains("Test Data not available")) 
		   	 					{
		   	 						iExitScenarioFlag = 1;
		   	 					}
		   	 					if (iExitScenarioFlag!=1)
		   	 					{
		   	 						Statement stPage = connection.createStatement();
		   	 						sqlPage = "Select * from `" + sPageID + "`  where EXECUTION_FLAG = 'Y' Order by SEQUENCE_NUMBER";
		   	 						ResultSet rsPage = stPage.executeQuery(sqlPage);
		   	 						while (rsPage.next())
		   	 						{
		   	 							try
		   	 							{
		   	 								strMethod = rsPage.getString("OBJECT_KEYWORD");
		   	 								String sSequenceNum = rsPage.getString("SEQUENCE_NUMBER");
		   	 								System.out.println("keywordname" +strMethod);
		   	 								MasterScriptMapping.strParent = rsPage.getString("OBJECT_PARENT");
		   	 								MasterScriptMapping.strChild = rsPage.getString("OBJECT_CHILD");
		   	 								MasterScriptMapping.Param1 = rsPage.getString("OBJECT_PARAM1");
		   	 								MasterScriptMapping.Param2 = rsPage.getString("OBJECT_PARAM2");
		   	 								MasterScriptMapping.Param3 = rsPage.getString("OBJECT_PARAM3");
		   	 								MasterScriptMapping.Param4 = rsPage.getString("OBJECT_PARAM4");
		   	 								MasterScriptMapping.Param5 = rsPage.getString("OBJECT_PARAM5"); 
		   	 								MasterScriptMapping.sScreenshot = rsPage.getString("PAGE_SCREENSHOT");
		   	 								MasterScriptMapping.sOnErrorFlag = rsPage.getString("PAGE_ONERRORACTION");
		   	 								System.out.println("test  --------------------            " +MasterScriptMapping.Param1);
		   	 								String strparam1 = KeywordRepository.GetData(MasterScriptMapping.Param1);
		   	 								System.out.println("strParam1" +strparam1);
		   	 								if (strparam1!=null && !strparam1.isEmpty())
		   	 								{
		   	 									for (int i = 0; i < m.length; i++)
		   	 									{
		   	 										if (strMethod.equals(m[i].getName()))
		   	 										{
		   	 											System.out.println(strMethod);
		   			   	 								logger.log(LogStatus.INFO,  "<span style='color:steelblue;'>Sequence Number : </span>" +sSequenceNum);
		   	 											logger.log(LogStatus.INFO,"<span style='color:steelblue;'>Keyword Name : </span>" +strMethod);
		   	 											try
		   	 											{
		   	 												if(MasterScriptMapping.sScreenshot.equalsIgnoreCase("YES"))
		   	 												{
		   	 													Thread.sleep(100);
		   	 													String screenShotPath = ReportLib.CaptureScreenshot(driver,sSuiteID.concat(sTestID).concat(sPageID).concat(strMethod).concat(sTCIteration));
		   	 													logger.log(LogStatus.INFO, "<span style='color:steelblue;'>Screenshot : </span>" +logger.addScreenCapture(screenShotPath));
		   	 												}
		   	 											}
		   	 											catch(Exception e)
		   	 											{
		   	 												//No Need Of Screenshots
		   	 											}
		   	 											m[i].invoke(strMethod);
		   	 											break;
		   	 										}
		   	 									}
		   	 								}
		   	 								else if(strparam1==null|| strparam1.isEmpty() || strparam1.equals(""))
		   	 								{
		   	 									iBreakflagSuite = 1;
		   	 								}
		   	 								if (sKeywordStatus == "0" || sKeywordStatus.equals("0"))
		   	 								{
		   	 									iBreakflagSuite = 1;
		   	 								}
		   	 								else if(sKeywordStatus == "1" || sKeywordStatus.equals("1"))
		   	 								{
		   	 									System.out.println("ON ERROR ACTION" +MasterScriptMapping.sOnErrorFlag);
		   	 									if(MasterScriptMapping.sOnErrorFlag==null||MasterScriptMapping.sOnErrorFlag.equalsIgnoreCase("")|| MasterScriptMapping.sOnErrorFlag.equalsIgnoreCase(" ")|| MasterScriptMapping.sOnErrorFlag.equals(null))
		   	 									{
		   	 										iBreakflagSuite =1;
		   	 										logger.log(LogStatus.FAIL , "<span style='color:steelblue;'>Keyword Failed</span>");
		   	 									}
		   	 									else if(MasterScriptMapping.sOnErrorFlag.equalsIgnoreCase("TERMINATE SUITE")|| MasterScriptMapping.sOnErrorFlag.equalsIgnoreCase("MOVE TO NEXT TESTSUITE"))
		   	 									{
		   	 										System.out.println("ACTION "+MasterScriptMapping.sOnErrorFlag);
		   	 										iBreakflagSuite = 0;
		   	 										logger.log(LogStatus.FAIL , "<span style='color:steelblue;'>Keyword Failed</span>");
		   	 										break;
		   	 									}
		   	 									else if(MasterScriptMapping.sOnErrorFlag.equalsIgnoreCase("Move To Next TestCase"))
		   	 									{
		   	 										System.out.println("ACTION "+MasterScriptMapping.sOnErrorFlag);
		   	 										iBreakflagSuite = 2;
		   	 										logger.log(LogStatus.FAIL , "<span style='color:steelblue;'>Keyword Failed</span>");
		   	 										break;
		   	 									}
		   	 								}
		   	 								else if (sKeywordStatus == "2" || sKeywordStatus.equals("2"))
		   	 								{
		   	 									iBreakflagSuite = 1;
		   	 									logger.log(LogStatus.SKIP , "<span style='color:steelblue;'>Keyword Skipped</span>");
		   	 								}
		   	 							}
		   	 							catch(Exception e)
		   	 							{
	   	 									iBreakflagSuite = 1;
		   	 								logger.log(LogStatus.FATAL,"<span style='color:steelblue;font-weight:bold'>Exception Occured - Page  : </span>" +e);
		   	 								System.out.println("Exception Occured -Page : "+e);
		   	 								e.printStackTrace();
		   	 							}
		   	 						}
		   	 						stPage.close();
		   	 						rsPage.close();
		   	 					}
		   	 				}
		   	 				catch(Exception e)
		   	 				{
		   	 					logger.log(LogStatus.FATAL,"<span style='color:steelblue;font-weight:bold'>Exception Occured - MasterTestMap  : </span>" +e);
		   	 					System.out.println("Exception Occured : MasterTestMap ");
		   	 					e.printStackTrace();
		   	 				}
		   	 				// Report Configurations
		   	 				reports.addSystemInfo("Host", "Manik Gandhi");
		   	 				reports.loadConfig(new File("./ConfigurationExtentReporting.xml"));
		   	 				System.out.println("Test Completed");
		   	 				if(iBreakflagSuite==2)
							{
								break;
							} 
		   	 				if(iBreakflagSuite==0)
		   	 				{
		   	 					break;
		   	 				} 
		   	 			} 
		   	 			stMasterTestMap.close();
		   	 			rsMasterTestMap.close();
		   	 		}
		   	 		catch(Exception e)
		   	 		{
		   	 			logger.log(LogStatus.FATAL,"<span style='color:steelblue;font-weight:bold'>Exception Occured - MasterSuiteTesMap : </span>" +e);
		   	 			System.out.println("Exception Occured : MasterSuiteTesMap");
		   	 			e.printStackTrace();
		   	 		}
		   	 		if(iBreakflagSuite==0)
		   	 		{
		   	 			break;
		   	 		} 
		   	 	reports.endTest(logger);
		   	 	}
		   	 	stMasterSuiteTestMap.close();
		   	 	rsMasterSuiteTestMap.close();
		   	 	//System.out.println("NOTE");
		   		}
			
			
			catch(Exception e)
			{
				logger.log(LogStatus.FATAL,"<span style='color:steelblue;font-weight:bold'>Exception Occured - MasterSuiteTesMapBrowser : </span>" +e);
   	 			System.out.println("Exception Occured : MasterSuiteTesMapBrowser");
   	 			e.printStackTrace();
			}
			Thread.sleep(1000);
			//driver.close();
		 	reports.flush();
			reports.close();
			//ReportLib.CreateFolder();
			//ReportLib.ReadMailXml();
			//ReportLib.SendMail();
			//ReportLib.removeDir();
		}
		stMasterSuiteTestMapBrowser.close();
		rsMasterSuiteTestMapBrowser.close();
	}
	catch(Exception e)
	{
		System.out.println("================EXCEPTION OCCURRED IN TEST================ ");
		e.printStackTrace();
	}	
}
@AfterTest
public static void AfterMasterSuiteTestMap()
{
	System.gc();
	Runtime.getRuntime().exit(1);
}
}