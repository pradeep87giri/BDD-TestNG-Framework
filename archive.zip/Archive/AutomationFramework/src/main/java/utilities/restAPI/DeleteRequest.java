package utilities.restAPI;

import static io.restassured.RestAssured.*;
import io.restassured.response.Response;
import utilities.selenium.Log;

public class DeleteRequest {

	public static void deleteRequest(String uri, String fieldName, String fieldValue) {

		try {
			Response resp = given().

					when().delete(uri + "/posts/" + fieldValue);
			Log.printInfo("Delete request successful and remaining values are : " + resp.asString());
		} catch (Exception e) {
			Log.printInfo("Delete request was not successful for : " + fieldName);
		}
	}
}
