package utilities.restAPI;

import static io.restassured.RestAssured.given;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import utilities.selenium.Log;

public class UpdateRequest {

	// putValue = {\"parameter\":\"value\", \"parameter2\":\"value2\"}
	public static void putRequestUpdateData(String uri, String fieldName, String fieldValue, String putValue) {
		try {
			Response resp = given().

					body(putValue).when().contentType(ContentType.JSON).put(uri + "/posts/" + fieldValue);

			Log.printInfo("Put request changes are made successfully and changed values are : " + resp.asString());
		} catch (Exception e) {
			Log.printInfo("Put request was not successful for : " + fieldName);
		}
	}

	// patchValue = {\"parameter\":\"value\"}
	public static void patchRequestUpdateData(String uri, String fieldName, String fieldValue, String patchValue) {
		try {
			Response resp = given().body(patchValue).when().contentType(ContentType.JSON)
					.put(uri + "/posts/" + fieldValue);

			Log.printInfo("Patch request changes are made successfully and changed values are : " + resp.asString());
		} catch (Exception e) {
			Log.printInfo("Patch request was not successful for : " + fieldName);
		}
	}

}
