package stepDefinitions;

import cucumber.api.java.en.When;
import pageObjectModel_Pages.ATOPage;

public class OrderWordDocValidation {

	@When("^Word Doc Validation \"([^\"]*)\"$")
	public void word_Doc_Validation(String action) throws Throwable {
		ATOPage.selectContractValidationOption(action);
	}
}
