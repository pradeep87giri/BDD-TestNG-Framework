package functional;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.HashMap;
import com.relevantcodes.extentreports.LogStatus;

public class MasterScriptLib extends  MasterScriptMapping
{
static DBConnection dbc = new DBConnection();
static Connection connection = dbc.CreateConnection();
public static String sLoadActionTestData,sqlPageDataSheet;
public static boolean blnDataNotFound;
public static HashMap<String, String> objMap = new HashMap<String, String>();

//Maps the Page_Datasheet with particular TestCase
public static String PageDataSheet()
{
	System.out.println("Entering PageDataSheet");
	try
	{
		sLoadActionTestData = "";		
		blnDataNotFound = true;		
		if (MasterScriptMapping.sPageDataSheetName != "") 
	    {
			try
			{
			System.out.println("testing the page occurence id------>  "+MasterScriptMapping.sPageOccID );
			sqlPageDataSheet = "Select *  from  `"+ MasterScriptMapping.sPageDataSheetName +"` where TEST_ID = '"+ MasterScriptMapping.sTestID + "' AND PAGE_OCCID = '"+MasterScriptMapping.sPageOccID+"' AND  TEST_ITERATION = '"+MasterScriptMapping.sTCIteration +"' " ;
			Statement stPageDataSheet = connection.createStatement();
			ResultSet rsPageDataSheet = stPageDataSheet.executeQuery(sqlPageDataSheet);
				while (rsPageDataSheet.next()) 
				{
					blnDataNotFound = false;
					ResultSetMetaData rsmd = rsPageDataSheet.getMetaData();         		            		 		        		
					for (int i = 1; i <= rsmd.getColumnCount(); i++ )
					{
						//we are fetching data on the basis of column numbers , come back again and check later
						String name = rsmd.getColumnName(i);
						objMap.put(name, rsPageDataSheet.getString(name)); 
						System.out.println("NAME---------> " +objMap.get(name));
					}        
				}
			}
			catch(Exception e)
			{
				//add logger statement
				logger.log(LogStatus.FATAL,"<span style='color:steelblue;font-weight:bold;'>Exception Occured - ToFetchColumns : </span>" +e);
				System.out.println("Exception Occured While Fetching Data  : PageDataSheet");
				e.printStackTrace();
			}
	    }
		else
	    {
			logger.log(LogStatus.ERROR,"<span style='color:steelblue;font-weight:bold;'>Datasheet Not Available</span>");
	    }  
		if (blnDataNotFound)
		{
			sLoadActionTestData = "Test Data not available";
			logger.log(LogStatus.ERROR,"<span style='color:steelblue;font-weight:bold;'>Data Not Available , Check the Test ID and Page ID</span>");
		}
		else
		{
			sLoadActionTestData = "";
		}
		}
		catch(Exception e)
		{
			//add logger statement
			logger.log(LogStatus.FATAL,"<span style='color:steelblue;font-weight:bold;'>Exception Occured - PageDataSheet : </span>" +e);
			System.out.println("Exception Occured : PageDataSheet");
			e.printStackTrace();
		}
	return sLoadActionTestData;	
}
public static void UnLoadActionTestData()
{
	// clearing all the values stored.
	objMap.clear();
}
}