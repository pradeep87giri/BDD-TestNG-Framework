package utilities.DB;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import baseClass.AppTest;
import utilities.selenium.ExcelDataConfig;
import utilities.selenium.Log;

public class DBConnection extends AppTest{

	
	
	protected static Connection connection = null;
		
	/**
	 * This method can be used to connect to a database which uses Service Name
	 * and runs the query specified
	 * 
	 * @param host
	 *            Host name of the database
	 * @param port
	 *            Port used to connect to the database
	 * @param serviceName
	 *            Service name used by the database
	 * @param username
	 *            User name used to connect to database
	 * @param password
	 *            Password used to connect to database
	 * @param query
	 *            Query to be run on the database
	 * @return {@link ResultSet} containing the result of the database query
	 * @throws Exception 
	 */
	public static ResultSet queryDatabaseUsingServiceName(String host, String port,
			String serviceName, String username, String password, String query) throws Exception {
		/*String url = "jdbc:oracle:thin:" + username + "/" + password + "@//"
			+ host + ":" + port + "/" + serviceName;*/
		String url = null;
		
		String database = ExcelDataConfig.getParameterValue(sheetPath, "DatabaseDetails", "DataBase");
		if (database.equalsIgnoreCase("Oracle")) {
			url = "jdbc:oracle:thin:" + "@//" + host + ":" + port + "/" + serviceName;
		} else if (database.equalsIgnoreCase("Mysql")) {
			url = "jdbc:mysql://" + host + ":" + port + "/" + serviceName;
		} else if (database.equalsIgnoreCase("Postgresql")) {
			url =  "jdbc:postgresql://" + host + ":" + port + "/" + serviceName;
		} else {
			System.out.println("Please specify Database Name correctly Oracle/Mysql/Postgresql");
		}
		
		try {
			System.out.println(query);
			System.out.println(url);	
			getConnection(url,username,password);
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(query);
			ResultSet resultSet = preparedStatement.executeQuery();
			 
			return resultSet;
		} catch (SQLException e) {
			
			Log.printWorkflow(("Database access error for queryDatabaseUsingServiceName() method for connection string - "
					+ url));
		
			throw new DatabaseAccessException(e);
		}
	}

	/**
	 * This method can be used to Connect to a database which uses SID and run
	 * the query specified
	 * 
	 * @param host
	 *            Host name of the database
	 * @param port
	 *            Port used to connect to the database
	 * @param sId
	 *            SID used by the database
	 * @param username
	 *            User name used to connect to database
	 * @param password
	 *            Password used to connect to database
	 * @param query
	 *            Query to be run on the database
	 * @return {@link ResultSet} containing the result of the database query
	 */
	protected static ResultSet queryDatabaseUsingSID(String host, String port,
			String sId, String username, String password, String query) {
		String url = "jdbc:oracle:thin:@" + host + ":" + port + ":" + sId;
		try {
			getConnection(url, username, password);
			PreparedStatement preparedStatement = connection
					.prepareStatement(query);
			ResultSet resultSet = preparedStatement.executeQuery();
			return resultSet;
		} catch (SQLException e) {
			
			Log.printWorkflow("Database access error for queryDatabaseUsingSID() method for connection string - "
					+ url);
	
			throw new DatabaseAccessException(e);
		}
	}

	/**
	 * Get connection to the database
	 * 
	 * @param url
	 *            Connection URL containing SID
	 * @param username
	 *            User name used to connect to database
	 * @param password
	 *            Password used to connect to database
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	private static void getConnection(String url, String username, String password) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			connection = DriverManager.getConnection(url, username, password);
			if (connection == null) {
				throw new DatabaseAccessException("Connection is null");
			} else {
				Log.printInfo("Connection successful using connection string "
						+ url);
			}
		} catch (ClassNotFoundException e) {
			throw new DatabaseAccessException(e);
		} catch (SQLException e) {
			throw new DatabaseAccessException(e);
		}
	}

	/**
	 * Get connection to the database
	 * 
	 * @param url
	 *            Connection URL containing Service name, User name and Password
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	private static void getConnection(String url) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(url);
			if (connection == null) {
				throw new DatabaseAccessException("Connection is null");
			} else {
				Log.printWorkflow("Connection successful using connection string "
						+ url);
			}
		} catch (ClassNotFoundException e) {
			throw new DatabaseAccessException(e);
		} catch (SQLException e) {
			throw new DatabaseAccessException(e);
		}
	}

	/**
	 * Close connection to the database
	 * 
	 * @throws SQLException
	 */
	public static void closeConnection() {
		try {
			connection.close();
			Log.printWorkflow("Connection close successful");
		} catch (SQLException e) {
			Log.printWarning("Connection close threw error");
			throw new DatabaseAccessException(e);
		}
	}

	
}
