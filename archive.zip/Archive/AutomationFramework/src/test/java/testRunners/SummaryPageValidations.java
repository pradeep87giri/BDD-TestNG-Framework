package testRunners;

import baseClass.AppTest;
import cucumber.api.CucumberOptions;

@CucumberOptions(features = "src/test/resources/Feature/SummaryPageValidations.feature",
tags = {"@RegressionTest"},
glue={"stepDefinitions"},
format = { "pretty",
"html:target/site/SummaryPageValidations",
"rerun:target/rerun.txt",
"json:target/SummaryPageValidations.json" },dryRun=false,monochrome = true)
public class SummaryPageValidations extends AppTest {

}
