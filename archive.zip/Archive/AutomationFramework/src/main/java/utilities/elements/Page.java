
package utilities.elements;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import utilities.selenium.Driver;
import utilities.selenium.Log;

/**
 * A library of basic functions that can be performed on any page. Serves as an
 * abstraction from the Selenium WebDriver. Use in place of Driver.Instance
 * wherever possible.
 */
public class Page {
	/**
	 * Verifies test state is at the correct page.
	 * 
	 * @param pageTitle
	 *            The title of the current page, displayed below the navigation
	 *            bar.
	 */
	public static void isAt(String... pageTitle) {
		List<String> pageTitleList = new ArrayList<String>(Arrays.asList(pageTitle));

		Log.printAction("Verifying current page is one of '" + pageTitleList + "'");

		Driver.waitForAjaxToComplete();

		String title = Driver.Instance.getTitle();

		boolean contains = false;

		for (String s : pageTitle) {
			if (title.contains(s)) {
				contains = true;
				break;
			}
		}

		if (!contains) {
			Assert.fail("Page title is: '" + title + "' expected one from: '" + pageTitleList + "'");
		}
	}

	/**
	 * Find and return a single WebElement with the specified selector and name.
	 * 
	 * @param by
	 *            Unique selector for a WebElement. Ex)
	 *            By.cssSelector("input[id='exampleID']").
	 * @param elementName
	 *            Logical name of element. This is what will show up in a
	 *            failure report if the element isn't found.
	 * @return WebElement if successfully found with given selector. Otherwise
	 *         returns null.
	 * @throws NoSuchElementException
	 *             If no matching elements are found.
	 */
	public static WebElement findElement(By by, String elementName) {
Driver.waitForAjaxToComplete();
		
		for (int seconds = 0;; seconds++)
		{
			try
			{
				return Driver.Instance.findElement(by);
			}
			catch (UnhandledAlertException e1) {throw e1;}
			catch (Exception e2)
			{
				if (seconds > Driver.timeOut)
					Assert.fail(elementName + " not found");	
			}
			Driver.pause(1);
		}
	}

	/**
	 * Find and return multiple elements that share the specified selector and
	 * name. Useful for situations where you need to iterate through multiple
	 * similar elements. For example, if you need to gather elements in a table
	 * and pick a row at a particular index.
	 * 
	 * @param by
	 *            Unique selector for a WebElement. Ex)
	 *            By.cssSelector("input[id='exampleID']").
	 * @param elementName
	 *            Logical name of element. This is what will show up in a
	 *            failure report if the element isn't found.
	 * @return A list of WebElements all sharing the given selector.
	 * @throws NoSuchElementException
	 *             If no matching elements are found.
	 */
	public static List<WebElement> findElements(By by, String elementName)
	{
		Driver.waitForAjaxToComplete();

		try
		{
			return Driver.Instance.findElements(by);
		}
		catch (UnhandledAlertException e1) {throw e1;}
		catch (NoSuchElementException e2)
		{
			Assert.fail(elementName + " not found");
			return null;
		}
	}


	/**
	 * Clicks a button determined by the specified locator. A button is described as a click-able
	 * box with text inside of it.
	 * 
	 * @param locator Unique locator for a WebElement. <i>Ex)
	 *            By.cssSelector("input[id='exampleID']")</i>.
	 * @param buttonName The name of the button for logging purposes.
	 */
	public static void clickButton(By locator, String buttonName)
	{
		Log.printInfo("Clicking '" + buttonName + "' button");
		
		Driver.waitForAjaxToComplete();
		
		for (int seconds = 0;; seconds++)
		{
			WebElement button = findElement(locator, "'" + buttonName + "' button");
			
			new WebDriverWait(Driver.Instance, Driver.timeOut).until(ExpectedConditions.elementToBeClickable(locator));
			
			Driver.pause(.5);
			
			try
			{
				button.click();
				break;
			}
			catch (Exception e1) {/* ignore */}
			
			if (seconds > Driver.timeOut)
				Assert.fail("Unable to click '" + buttonName + "' button");
			
			Driver.pause(.5);
		}
	}
	
	/**
	 * Clicks a button. A button is described as a click-able
	 * box with text inside of it.
	 * 
	 * @param button WebElement representing the button.
	 * @param buttonName The name of the button for logging purposes.
	 */
	public static void clickButton(WebElement button, String buttonName)
	{
		Log.printInfo("Clicking '" + buttonName + "' button");
		
		Driver.waitForAjaxToComplete();

		for (int seconds = 0;; seconds++)
		{
			new WebDriverWait(Driver.Instance, Driver.timeOut).until(ExpectedConditions.elementToBeClickable(button));
			
			Driver.pause(.5);
			
			try
			{
				button.click();
				break;
			}
			catch (Exception e1) {/* ignore */}
			
			if (seconds > Driver.timeOut)
				Assert.fail("Unable to click '" + buttonName + "' button");
			
			Driver.pause(.5);
		}
	}
	
	/**
	 * Clicks a link by the specified locator. A link is anything in the page that is wrapped by
	 * "a tags".
	 * 
	 * @param locator Unique locator for a WebElement. <i>Ex)
	 *            By.cssSelector("input[id='exampleID']")</i>.
	 * @param linkName The name of the link for logging purposes.
	 */
	public static void clickLink(By locator, String linkName)
	{
		Log.printInfo("Clicking '" + linkName + "' link");

		Driver.waitForAjaxToComplete();
		
		for (int seconds = 0;; seconds++)
		{
			WebElement link = Page.findElement(locator, "'" + linkName + "' link");
			
			new WebDriverWait(Driver.Instance, Driver.timeOut).until(ExpectedConditions.elementToBeClickable(locator));
			
			try
			{
				link.click();
				break;
			}
			catch (Exception e1) {/* ignore */}
			
			if (seconds > Driver.timeOut)
				Assert.fail("Unable to click '" + linkName + "' link");
			
			Driver.pause(1);
		}
	}
	
	/**
	 * Clicks an element on the page.
	 * 
	 * @param element WebElement to click.
	 * @param elementName The name of the element for logging purposes.
	 */
	public static void clickElement(WebElement element, String elementName)
	{
		Log.printInfo("Clicking '" + elementName + "' element");

		Driver.waitForAjaxToComplete();
		
		for (int seconds = 0;; seconds++)
		{
			try
			{
				element.click();
				break;
			}
			catch (Exception e1) {/* ignore */}
			
			if (seconds > Driver.timeOut)
				Assert.fail("Unable to click '" + elementName + "' element");
			
			Driver.pause(1);
		}
	}
	
	/**
	 * This sub class will handle all methods that use the Actions.moveToElement to handle problems
	 * with the element being visible.
	 */
	public static class MoveToElement
	{
		/**
		 * Clicks a button determined by the specified locator. A button is described as a click-able
		 * box with text inside of it.
		 * 
		 * @param locator Unique locator for a WebElement. <i>Ex)
		 *            By.cssSelector("input[id='exampleID']")</i>.
		 * @param buttonName The name of the button for logging purposes.
		 */
		public static void clickButton(By locator, String buttonName)
		{
			Log.printInfo("Clicking '" + buttonName + "' button");
			
			Driver.waitForAjaxToComplete();
	
			for (int seconds = 0;; seconds++)
			{
				WebElement button = findElement(locator, "'" + buttonName + "' button");
				
				new WebDriverWait(Driver.Instance, Driver.timeOut).until(ExpectedConditions.elementToBeClickable(locator));
				
				Driver.pause(.5);
				
				try
				{
					button.click();
					break;
				}
				catch (Exception e1)
				{
					try
					{
						Actions build = new Actions(Driver.Instance);
						build.moveToElement(button, 0, 0).click().build().perform();
						break;
					}
					catch (Exception e2) {/* ignore */}
				}
				
				if (seconds > Driver.timeOut)
					Assert.fail("Unable to click '" + buttonName + "' button");
				
				Driver.pause(.5);
			}
		}
	
		/**
		 * Clicks a button. A button is described as a click-able
		 * box with text inside of it.
		 * 
		 * @param button WebElement representing the button.
		 * @param buttonName The name of the button for logging purposes.
		 */
		public static void clickButton(WebElement button, String buttonName)
		{
			Log.printInfo("Clicking '" + buttonName + "' button");
			
			Driver.waitForAjaxToComplete();
	
			for (int seconds = 0;; seconds++)
			{
				new WebDriverWait(Driver.Instance, Driver.timeOut).until(ExpectedConditions.elementToBeClickable(button));
				
				Driver.pause(.5);
				
				try
				{
					button.click();
					break;
				}
				catch (Exception e1)
				{
					try
					{
						Actions build = new Actions(Driver.Instance);
						build.moveToElement(button, 0, 0).click().build().perform();
						break;
					}
					catch (Exception e2) {/* ignore */}
				}
				
				if (seconds > Driver.timeOut)
					Assert.fail("Unable to click '" + buttonName + "' button");
				
				Driver.pause(.5);
			}
		}
		
		/**
		 * Clicks a link by the specified locator. A link is anything in the page that is wrapped by
		 * "a tags".
		 * 
		 * @param locator Unique locator for a WebElement. <i>Ex)
		 *            By.cssSelector("input[id='exampleID']")</i>.
		 * @param linkName The name of the link for logging purposes.
		 */
		public static void clickLink(By locator, String linkName)
		{
			Log.printInfo("Clicking '" + linkName + "' link");

			Driver.waitForAjaxToComplete();
			
			for (int seconds = 0;; seconds++)
			{
				WebElement link = Page.findElement(locator, "'" + linkName + "' link");
				
				new WebDriverWait(Driver.Instance, Driver.timeOut).until(ExpectedConditions.elementToBeClickable(locator));
				
				try
				{
					link.click();
					break;
				}
				catch (Exception e1)
				{
					try
					{
						Actions build = new Actions(Driver.Instance);
						build.moveToElement(link, 0, 0).click().build().perform();
						break;
					}
					catch (Exception e2) {/* ignore */}
				}
				
				if (seconds > Driver.timeOut)
					Assert.fail("Unable to click '" + linkName + "' link");
				
				Driver.pause(1);
			}
		}
		
		
		
		/**
		 * Clicks an element on the page.
		 * 
		 * @param element WebElement to click.
		 * @param elementName The name of the element for logging purposes.
		 */
		public static void clickElement(WebElement element, String elementName)
		{
			Log.printInfo("Clicking '" + elementName + "' element");

			Driver.waitForAjaxToComplete();
			
			for (int seconds = 0;; seconds++)
			{
				try
				{
					element.click();
					break;
				}
				catch (Exception e1)
				{
					try
					{
						Actions build = new Actions(Driver.Instance);
						build.moveToElement(element, 0, 0).click().build().perform();
						break;
					}
					catch (Exception e2) {/* ignore */}
				}
				
				if (seconds > Driver.timeOut)
					Assert.fail("Unable to click '" + elementName + "' element");
				
				Driver.pause(1);
			}
		}
	}

	/**
	 * Compares the expected string to the actual string and asserts a failure
	 * if they are not equal.
	 * 
	 * @param expected
	 *            The string you expect to find.
	 * @param actual
	 *            The string from a WebElement that wish to verify.
	 */
	public static void verifyText(String expected, String actual) {
		if (expected.contains("\\s"))
			expected = expected.replaceAll("\\s+", "");

		if (!expected.equals(actual)) {
			Assert.fail("Expected text is: " + expected + " - Actual text is: " + actual);
		}
	}

	/** Returns the text of a WebElement 
	 * @return **/
	
	public static void verifyTextOnPage(String text) {
		List<WebElement> list = Driver.Instance.findElements(By.xpath("//*[contains(text(),'" + text + "')]"));
		if(list.size() > 0){
			Log.printInfo("Text is present : " + text);
		}
	}

	/** Returns the text is visible on Page or not **/

	public static String getText(By by) {
		return Driver.Instance.findElement(by).getText();

	}
	
	
	public static void verifyInts(int expected, int actual) {
		Log.printAction("Verifying that the expected number: " + expected + " equals the actual number: " + actual);

		if (expected != actual) {
			Assert.fail("Expected number is: " + expected + " - Actual number is: " + actual);
		}
	}

	public static void verifyGBP(double expected, double actual) {
		Log.printAction("Verifying that the expected number: " + expected + " equals the actual number: " + actual);

		if (expected != actual) {
			Assert.fail("Expected number is: " + expected + " - Actual number is: " + actual);
		}
	}

	// Explicit Wait till the element is present
	public static void presenceOfElementWait(int timeout, By by, String elementName) {
		try {
			new WebDriverWait(Driver.Instance, timeout).until(ExpectedConditions.presenceOfElementLocated(by));
		} catch (NoSuchElementException e) {
			Assert.fail(elementName + "Not found");
		}
	}

	// Explicit Wait till the element is visible

	public static void visiblityOfElementWait(int timeout, By by, String elementName) {
		try {
			new WebDriverWait(Driver.Instance, timeout).until(ExpectedConditions.visibilityOfElementLocated(by));
		} catch (NoSuchElementException e) {
			Assert.fail(elementName + "Not found");
		}
	}

	
	
	public static void visiblityOfElementsWait(int timeout, By by, String elementName) {
		try {
			new WebDriverWait(Driver.Instance, timeout).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(by));
		} catch (NoSuchElementException e) {
			Assert.fail(elementName + "Not found");
		}
	}
	
	// Returns Select WebElement
	
	public static Select selectElement(By by,String elementName){
		WebElement element= findElement(by, elementName);
	return	new Select(element);
	}
	
	public static int isPresentElement(By by,String elementName){
		int element= Driver.Instance.findElements(by).size();
		return element;
	}
}
