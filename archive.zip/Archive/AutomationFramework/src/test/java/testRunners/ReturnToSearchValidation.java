package testRunners;

import baseClass.AppTest;
import cucumber.api.CucumberOptions;

@CucumberOptions(features = "src/test/resources/Feature/ReturnToSearchValidation.feature",
tags = {"@RegressionTest"},
glue={"stepDefinitions"},
format = { "pretty",
"html:target/site/ReturnToSearchValidation",
"rerun:target/rerun.txt",
"json:target/ReturnToSearchValidation.json" },dryRun=false,monochrome = true)

public class ReturnToSearchValidation extends AppTest{

	
}
