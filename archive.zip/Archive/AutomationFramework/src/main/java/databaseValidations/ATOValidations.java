package databaseValidations;

import java.sql.ResultSet;

import baseClass.AppTest;
import utilities.DB.DBConnection;
import utilities.parameters.ParameterTable;
import utilities.selenium.ExcelDataConfig;
import utilities.selenium.Log;

public class ATOValidations extends AppTest {

	public static void OrdNum(String orderNum) throws Exception {
		
		String HostName = ExcelDataConfig.getParameterValue(sheetPath, "DatabaseDetails", "DBHostName_" + environment);
		String ServiceName = ExcelDataConfig.getParameterValue(sheetPath, "DatabaseDetails", "DBServiceName_" + environment);
		String UserName = ExcelDataConfig.getParameterValue(sheetPath, "DatabaseDetails", "DBUserName_" + environment);
		String Password = ExcelDataConfig.getParameterValue(sheetPath, "DatabaseDetails", "DBPassword_" + environment);
		String query1 = ExcelDataConfig.getParameterValue(sheetPath, "DatabaseDetails", "OrderDetailsQuery1_" + environment);
		String query2 = ExcelDataConfig.getParameterValue(sheetPath, "DatabaseDetails", "OrderDetailsQuery2_" + environment);
		String query3 = ExcelDataConfig.getParameterValue(sheetPath, "DatabaseDetails", "AENameQuery_" + environment);
		String Port = ExcelDataConfig.getParameterValue(sheetPath, "DatabaseDetails", "DBPort_" + environment);
		
		
		ResultSet resultSet = DBConnection.queryDatabaseUsingServiceName(HostName, Port, ServiceName, UserName,
				Password, query1 + orderNum + query2 + orderNum);

		while (resultSet.next()) {
			
			String DBOrderNum = resultSet.getString("ord_num");
			String DBQuoteID = resultSet.getString("quote_id");
			String DBstatus_cd = resultSet.getString("ord_orst_cd");
			if(DBstatus_cd.equals("4")) {
				DBstatus_cd = "RECEIVED";
			}
			String DBClient_ID = resultSet.getString("client_id");
			String DBAE_Emp_CD = resultSet.getString("ord_emp_cd");
			
			ParameterTable.add("DBOrder_Num", DBOrderNum);
			ParameterTable.add("DBQuote_ID", DBQuoteID);
			ParameterTable.add("DBStaus_CD", DBstatus_cd);
			ParameterTable.add("DBOrderClient_ID", DBClient_ID);
			
			ResultSet resultSet1 = DBConnection.queryDatabaseUsingServiceName(HostName, Port, ServiceName, UserName,
					Password, query3 + DBAE_Emp_CD);
			
			while (resultSet1.next()) {
				String DBAE_Name = resultSet1.getString("emp_name");
			
				DBAE_Name = DBAE_Name.toUpperCase();
				ParameterTable.add("DBAE_Name", DBAE_Name);
			
		}
		
		}
		DBConnection.closeConnection();
	}

}
