package functional;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;

import com.google.common.base.Function;
import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.JavascriptExecutor;

public class KeywordRepository extends MasterScriptMapping {
	static DBConnection dbc = new DBConnection();
	static Connection connection = dbc.CreateConnection();
	public static WebElement we;
	public static WebElement ele;
	public static By locator;

	public static String GetData(String param) {
		System.out.println("In keyword Repository" + MasterScriptMapping.Param1);
		return MasterScriptLib.objMap.get(param);
	}

	// Get the Object Property from MasterPageObjectMap
	public static WebElement GetObj(String strObj) throws Exception {
		try {
			String strId = "";
			String strName = "";
			String strTagName = "";
			String strLinkText = "";
			String strXPath = "";
			String strClass = "";
			String strCSS = "";
			Statement stMasterPageObjectMap = connection.createStatement();
			ResultSet rsMasterPageObjectMap = stMasterPageObjectMap.executeQuery("select * from MasterPageObjectMap");
			while (rsMasterPageObjectMap.next()) {
				String sParent = MasterScriptMapping.strParent;
				if (strObj.equals(rsMasterPageObjectMap.getString("OBJECT_CHILD"))
						&& (sParent.equals(rsMasterPageObjectMap.getString("OBJECT_PARENT")))) {
					System.out.println("check in");
					strId = rsMasterPageObjectMap.getString("ID");
					strName = rsMasterPageObjectMap.getString("NAME");
					strTagName = rsMasterPageObjectMap.getString("TAGNAME");
					strLinkText = rsMasterPageObjectMap.getString("LINKTEXT");
					strXPath = rsMasterPageObjectMap.getString("XPATH");
					strCSS = rsMasterPageObjectMap.getString("CSS");
					strClass = rsMasterPageObjectMap.getString("CLASS");
					break;
				}
			}
			rsMasterPageObjectMap.close();
			stMasterPageObjectMap.close();
			if (strId != null) {
				logger.log(LogStatus.INFO, "<span style='color:steelblue'>Object ID : </span>" + strId);
				locator = By.id(strId);
				MasterScriptMapping.dynamicWait.until(ExpectedConditions.visibilityOfElementLocated(locator));
				we = MasterScriptMapping.driver.findElement(locator);
			} else if (strName != null) {
				logger.log(LogStatus.INFO, "<span style='color:steelblue;'>Object Name : </span>" + strName);
				locator = By.name(strName);
				MasterScriptMapping.dynamicWait.until(ExpectedConditions.visibilityOfElementLocated(locator));
				we = MasterScriptMapping.driver.findElement(locator);
				we = MasterScriptMapping.driver.findElement(By.name(strName));
			} else if (strTagName != null) {
				logger.log(LogStatus.INFO, "<span style='color:steelblue;'>Object TagName : </span>" + strTagName);
				locator = By.tagName(strTagName);
				MasterScriptMapping.dynamicWait.until(ExpectedConditions.visibilityOfElementLocated(locator));
				we = MasterScriptMapping.driver.findElement(locator);
				we = MasterScriptMapping.driver.findElement(By.tagName(strTagName));
			} else if (strLinkText != null) {
				logger.log(LogStatus.INFO, "<span style='color:steelblue'>Object LinkText : </span>" + strLinkText);
				locator = By.linkText(strLinkText);
				MasterScriptMapping.dynamicWait.until(ExpectedConditions.visibilityOfElementLocated(locator));
				we = MasterScriptMapping.driver.findElement(locator);
				we = MasterScriptMapping.driver.findElement(By.linkText(strLinkText));
			} else if (strXPath != null) {
				logger.log(LogStatus.INFO, "<span style='color:steelblue'>Object Xpath : </span>" + strXPath);
				locator = By.xpath(strXPath);
				MasterScriptMapping.dynamicWait.until(ExpectedConditions.visibilityOfElementLocated(locator));
				we = MasterScriptMapping.driver.findElement(locator);
				we = MasterScriptMapping.driver.findElement(By.xpath(strXPath));
			} else if (strClass != null) {
				logger.log(LogStatus.INFO, "<span style='color:steelblue'>Object Class : </span>" + strClass);
				locator = By.className(strClass);
				MasterScriptMapping.dynamicWait.until(ExpectedConditions.visibilityOfElementLocated(locator));
				we = MasterScriptMapping.driver.findElement(locator);
				we = MasterScriptMapping.driver.findElement(By.className(strClass));
			} else {
				logger.log(LogStatus.INFO, "<span style='color:steelblue'>Object CSS : </span>" + strCSS);
				locator = By.cssSelector(strCSS);
				MasterScriptMapping.dynamicWait.until(ExpectedConditions.visibilityOfElementLocated(locator));
				we = MasterScriptMapping.driver.findElement(locator);
				we = MasterScriptMapping.driver.findElement(By.cssSelector(strCSS));
			}
			return we;
		} catch (Exception e) {
			MasterScriptMapping.sActualResult = e.getMessage();
			logger.log(LogStatus.FATAL,
					"<span style='color:steelblue;font-weight:bold;'>Exception Occured - While Getting Object Property : </span>"
							+ e);
			throw (e);
		}
	}

	// keywords to be used
	public static void Launch() throws Exception {
		try {
			String strUrl = KeywordRepository.GetData(MasterScriptMapping.Param1);
			logger.log(LogStatus.INFO, "<span style='color:steelblue'>Param1 : </span>" + MasterScriptMapping.Param1);
			MasterScriptMapping.driver.get(strUrl);
			MasterScriptMapping.driver.manage().window().maximize();
			MasterScriptMapping.sActualResult = "<span style='color:steelblue;font-weight:bold;'>Url : '" + strUrl
					+ "'  Launched successfully </span>";
			logger.log(LogStatus.PASS, MasterScriptMapping.sActualResult);
			MasterScriptMapping.sKeywordStatus = "0";
		} catch (Exception e) {
			MasterScriptMapping.sActualResult = e.getMessage();
			logger.log(LogStatus.FATAL,
					"<span style='color:steelblue;font-weight:bold;'>Exception Occured - Keyword Launch : </span>" + e);
			MasterScriptMapping.sKeywordStatus = "1";
		}
	}

	//
	public static void setWebText() throws Exception {
		try {
			String strText = KeywordRepository.GetData(MasterScriptMapping.Param1);
			we = GetObj(MasterScriptMapping.strChild);
			((JavascriptExecutor) MasterScriptMapping.driver).executeScript("arguments[0].scrollIntoView();", we);
			MasterScriptMapping.dynamicWait.until(ExpectedConditions.visibilityOf(we));
			we.sendKeys(strText);
			logger.log(LogStatus.INFO,
					"<span style='color:steelblue'>Object Parent : </span>" + MasterScriptMapping.strParent);
			logger.log(LogStatus.INFO,
					"<span style='color:steelblue'>Object Child : </span>" + MasterScriptMapping.strChild);
			MasterScriptMapping.sActualResult = "<span style='color:steelblue;font-weight:bold;'>Data : '" + strText
					+ "' has been set successfully</span>";
			logger.log(LogStatus.PASS, MasterScriptMapping.sActualResult);
			MasterScriptMapping.sKeywordStatus = "0";
		} catch (Exception e) {
			MasterScriptMapping.sActualResult = e.getMessage();
			logger.log(LogStatus.FATAL,
					"<span style='color:steelblue;font-weight:bold;'>Exception Occured - Keyword SetWebText : </span>"
							+ e);
			MasterScriptMapping.sKeywordStatus = "1";
		}
	}

	public static void setWebTextAndEnter() throws Exception {
		try {
			String strText = KeywordRepository.GetData(MasterScriptMapping.Param1);
			we = GetObj(MasterScriptMapping.strChild);
			((JavascriptExecutor) MasterScriptMapping.driver).executeScript("arguments[0].scrollIntoView();", we);
			MasterScriptMapping.dynamicWait.until(ExpectedConditions.visibilityOf(we));
			we.sendKeys(strText, Keys.ENTER);
			logger.log(LogStatus.INFO,
					"<span style='color:steelblue'>Object Parent : </span>" + MasterScriptMapping.strParent);
			logger.log(LogStatus.INFO,
					"<span style='color:steelblue'>Object Child : </span>" + MasterScriptMapping.strChild);
			MasterScriptMapping.sActualResult = "<span style='color:steelblue;font-weight:bold;'>Data : '" + strText
					+ "' has been set successfully</span>";
			logger.log(LogStatus.PASS, MasterScriptMapping.sActualResult);
			MasterScriptMapping.sKeywordStatus = "0";
		} catch (Exception e) {
			MasterScriptMapping.sActualResult = e.getMessage();
			logger.log(LogStatus.FATAL,
					"<span style='color:steelblue;font-weight:bold;'>Exception Occured - Keyword SetWebText : </span>"
							+ e);
			MasterScriptMapping.sKeywordStatus = "1";
		}
	}

	//
	public static void setWebTextFocus() throws Exception {
		try {
			String strText = KeywordRepository.GetData(MasterScriptMapping.Param1);
			we = GetObj(MasterScriptMapping.strChild);
			((JavascriptExecutor) MasterScriptMapping.driver).executeScript("arguments[0].scrollIntoView();", we);
			MasterScriptMapping.dynamicWait.until(ExpectedConditions.visibilityOf(we));
			Actions actions = new Actions(MasterScriptMapping.driver);
			actions.moveToElement(we);
			Thread.sleep(100);
			actions.click();
			actions.build().perform();
			Thread.sleep(1000);
			actions.sendKeys(strText).build().perform();
			logger.log(LogStatus.INFO,
					"<span style='color:steelblue'>Object Parent : </span>" + MasterScriptMapping.strParent);
			logger.log(LogStatus.INFO,
					"<span style='color:steelblue'>Object Child : </span>" + MasterScriptMapping.strChild);
			MasterScriptMapping.sActualResult = "<span style='color:steelblue;font-weight:bold'>Data : '" + strText
					+ "' has been set successfully</span>";
			logger.log(LogStatus.PASS, MasterScriptMapping.sActualResult);
			MasterScriptMapping.sKeywordStatus = "0";

		} catch (Exception e) {
			MasterScriptMapping.sActualResult = e.getMessage();
			e.printStackTrace();
			logger.log(LogStatus.FATAL,
					"<span style='color:steelblue;font-weight:bold;'>Exception Occured - Keyword SetWebTextFocus : </span>"
							+ e);
			MasterScriptMapping.sKeywordStatus = "1";
		}
	}

	//
	public static void switchToFrame() throws Exception {
		try {
			String strswitchToFrame = KeywordRepository.GetData(MasterScriptMapping.Param1);
			if (strswitchToFrame.equalsIgnoreCase("Yes")) {
				logger.log(LogStatus.INFO,
						"<span style='color:steelblue'>Object Parent : </span>" + MasterScriptMapping.strParent);
				logger.log(LogStatus.INFO,
						"<span style='color:steelblue'>Object Child : </span>" + MasterScriptMapping.strChild);
				we = GetObj(MasterScriptMapping.strChild);
				MasterScriptMapping.dynamicWait.until(ExpectedConditions.visibilityOf(we));
				MasterScriptMapping.driver.switchTo().frame(we);
				MasterScriptMapping.sActualResult = "<span style='color:steelblue;font-weight:bold'>Switch To Frame has been done sucessfully</span>";
				logger.log(LogStatus.PASS, MasterScriptMapping.sActualResult);
				MasterScriptMapping.sKeywordStatus = "0";
			} else {
				logger.log(LogStatus.SKIP,
						"<span style='color:steelblue;font-weight:bold'>Keyword Skipped - switchToFrame</span>");
				MasterScriptMapping.sKeywordStatus = "2";
			}
		} catch (Exception e) {
			MasterScriptMapping.sActualResult = e.getMessage();
			logger.log(LogStatus.FATAL,
					"<span style='color:steelblue;font-weight:bold;'>Exception Occured - Keyword switchToFrame : </span>"
							+ e);
			MasterScriptMapping.sKeywordStatus = "1";
		}
	}

	//
	public static void switchToDefaultContent() throws Exception {
		try {
			String strClickElement = KeywordRepository.GetData(MasterScriptMapping.Param1);
			if (strClickElement.equalsIgnoreCase("Yes")) {
				MasterScriptMapping.driver.switchTo().defaultContent();
				MasterScriptMapping.sActualResult = "<span style='color:steelblue;font-weight:bold;'>Switched to default content  successfully</span>";
				logger.log(LogStatus.PASS, MasterScriptMapping.sActualResult);
				MasterScriptMapping.sKeywordStatus = "0";
			} else {
				logger.log(LogStatus.SKIP,
						"<span style='color:steelblue;font-weight:bold'>Keyword Skipped - switchToDefaultContent</span>");
				MasterScriptMapping.sKeywordStatus = "2";
			}
		} catch (Exception e) {
			MasterScriptMapping.sActualResult = e.getMessage();
			logger.log(LogStatus.FATAL,
					"<span style='color:steelblue;font-weight:bold;\'>Exception Occured - Keyword switchToDefaultContent : </span>"
							+ e);
			MasterScriptMapping.sKeywordStatus = "1";
		}
	}

	//
	public static void ClickElement() throws Exception {
		try {
			String strClickElement = KeywordRepository.GetData(MasterScriptMapping.Param1);
			if (strClickElement.equalsIgnoreCase("Yes")) {
				logger.log(LogStatus.INFO,
						"<span style='color:steelblue'>Object Parent : </span>" + MasterScriptMapping.strParent);
				logger.log(LogStatus.INFO,
						"<span style='color:steelblue'>Object Child : </span>" + MasterScriptMapping.strChild);
				we = GetObj(MasterScriptMapping.strChild);
				((JavascriptExecutor) MasterScriptMapping.driver).executeScript("arguments[0].scrollIntoView();", we);
				MasterScriptMapping.dynamicWait.until(ExpectedConditions.visibilityOf(we));
				we.click();
				MasterScriptMapping.sActualResult = "<span style='color:steelblue;font-weight:bold'>Element : '"
						+ MasterScriptMapping.strChild + "' has been clicked successfully</span>";
				logger.log(LogStatus.PASS, MasterScriptMapping.sActualResult);
				MasterScriptMapping.sKeywordStatus = "0";
			} else {
				logger.log(LogStatus.SKIP,
						"<span style='color:steelblue;font-weight:bold;'>Keyword Skipped - ClickElement</span>");
				MasterScriptMapping.sKeywordStatus = "2";
			}
		} catch (Exception e) {
			MasterScriptMapping.sActualResult = e.getMessage();
			logger.log(LogStatus.FATAL,
					"<span style='color:steelblue;font-weight:bold;'>Exception Occured - Keyword ClickElement : </span>"
							+ e);
			MasterScriptMapping.sKeywordStatus = "1";
		}
	}

	//
	public static void ClickElementFromParameter() throws Exception {
		try {
			String strClickElement = KeywordRepository.GetData(MasterScriptMapping.Param1);
			if (!strClickElement.equals(null) && !strClickElement.equals("")) {
				logger.log(LogStatus.INFO,
						"<span style='color:steelblue'>Object Parent : </span>" + MasterScriptMapping.strParent);
				logger.log(LogStatus.INFO,
						"<span style='color:steelblue'>Object Child : </span>" + MasterScriptMapping.strChild);
				we = MasterScriptMapping.driver.findElement(By.xpath(strClickElement));
				((JavascriptExecutor) MasterScriptMapping.driver).executeScript("arguments[0].scrollIntoView();", we);
				MasterScriptMapping.dynamicWait.until(ExpectedConditions.visibilityOf(we));
				we.click();
				MasterScriptMapping.sActualResult = "<span style='color:steelblue;font-weight:bold'>Element : '"
						+ MasterScriptMapping.Param1 + "' has been clicked successfully</span>";
				logger.log(LogStatus.PASS, MasterScriptMapping.sActualResult);
				MasterScriptMapping.sKeywordStatus = "0";
			} else {
				logger.log(LogStatus.SKIP,
						"<span style='color:steelblue;font-weight:bold;'>Keyword Skipped - ClickElementfromParameter</span>");
				MasterScriptMapping.sKeywordStatus = "2";
			}
		} catch (Exception e) {
			MasterScriptMapping.sActualResult = e.getMessage();
			logger.log(LogStatus.FATAL,
					"<span style='color:steelblue;font-weight:bold;'>Exception Occured - Keyword ClickElementfromParameter : </span>"
							+ e);
			MasterScriptMapping.sKeywordStatus = "1";
		}
	}

	//
	public static void WaitFor() throws Exception {
		try {
			String strTime = KeywordRepository.GetData(MasterScriptMapping.Param1);
			Long lTimeSec = Long.parseLong((strTime.toString())) * 1000L;
			logger.log(LogStatus.INFO, "<span style='color:steelblue'>Param1 : </span>" + MasterScriptMapping.Param1);
			Thread.sleep(lTimeSec);
			MasterScriptMapping.sActualResult = "<span style='color:steelblue;font-weight:bold;'>Wait successful for time : '"
					+ strTime + "' seconds</span>";
			logger.log(LogStatus.PASS, MasterScriptMapping.sActualResult);
			MasterScriptMapping.sKeywordStatus = "0";
		} catch (Exception e) {
			MasterScriptMapping.sActualResult = e.getMessage();
			logger.log(LogStatus.FATAL,
					"<span style='color:steelblue;font-weight:bold;'>Exception Occured - Keyword WaitFor : </span>"
							+ e);
			MasterScriptMapping.sKeywordStatus = "1";
		}
	}

	public static <WebDriver, Seconds> void fluentWait() throws Exception {
		try {
			String strClickElement = KeywordRepository.GetData(MasterScriptMapping.Param1);
			if (!strClickElement.equals(null) && !strClickElement.equals("")) {
				logger.log(LogStatus.INFO,
						"<span style='color:steelblue'>Object Parent : </span>" + MasterScriptMapping.strParent);
				logger.log(LogStatus.INFO,
						"<span style='color:steelblue'>Object Child : </span>" + MasterScriptMapping.strChild);
				we = GetObj(MasterScriptMapping.strChild);
				Wait<WebDriver> wait = new FluentWait<WebDriver>((WebDriver) driver)
						.withTimeout(180, TimeUnit.SECONDS).pollingEvery(3, TimeUnit.SECONDS)
						.ignoring(NoSuchElementException.class);
				WebElement element = wait.until(new Function<WebDriver, WebElement>() {

					public WebElement apply(WebDriver driver) {
						ele = we;

						if (ele.isDisplayed()) {
							return ele;
						} else {
							return null;
						}
					}

				});
				System.out.println("Element is Displayed? :" + element.isDisplayed());
				((JavascriptExecutor) MasterScriptMapping.driver).executeScript("arguments[0].scrollIntoView();", ele);
				ele.click();
				MasterScriptMapping.sActualResult = "<span style='color:steelblue;font-weight:bold'>Element : '"
						+ MasterScriptMapping.Param1 + "' has been clicked successfully</span>";
				logger.log(LogStatus.PASS, MasterScriptMapping.sActualResult);
				MasterScriptMapping.sKeywordStatus = "0";
			} else {
				logger.log(LogStatus.SKIP,
						"<span style='color:steelblue;font-weight:bold;'>Keyword Skipped - ClickElementfromParameter</span>");
				MasterScriptMapping.sKeywordStatus = "2";
			}
		} catch (Exception e) {
			MasterScriptMapping.sActualResult = e.getMessage();
			logger.log(LogStatus.FATAL,
					"<span style='color:steelblue;font-weight:bold;'>Exception Occured - Keyword ClickElementfromParameter : </span>"
							+ e);
			MasterScriptMapping.sKeywordStatus = "1";
		}

	}

	public static void RefreshPage() throws Exception {
		try {
			String strRefreshpage = KeywordRepository.GetData(MasterScriptMapping.Param1);
			if (strRefreshpage.equalsIgnoreCase("Yes")) {
				logger.log(LogStatus.INFO,
						"<span style='color:steelblue'>Param1 : </span>" + MasterScriptMapping.Param1);
				MasterScriptMapping.driver.navigate().refresh();
				MasterScriptMapping.sActualResult = "<span style='color:steelblue;font-weight:bold;'>Refresh successful</span>";
				logger.log(LogStatus.PASS, MasterScriptMapping.sActualResult);
				MasterScriptMapping.sKeywordStatus = "0";
			} else {
				logger.log(LogStatus.SKIP,
						"<span style='color:steelblue;font-weight:bold;'>Keyword Skipped - RefreshPage</span>");
				MasterScriptMapping.sKeywordStatus = "2";
			}
		} catch (Exception e) {
			MasterScriptMapping.sActualResult = e.getMessage();
			logger.log(LogStatus.FATAL,
					"<span style='color:steelblue;font-weight:bold;'>Exception Occured - Keyword WaitFor : </span>"
							+ e);
			MasterScriptMapping.sKeywordStatus = "1";
		}
	}

	//
	public static void ClearText() {
		try {
			String strClearText = KeywordRepository.GetData(MasterScriptMapping.Param1);
			if (strClearText.equalsIgnoreCase("Yes")) {
				logger.log(LogStatus.INFO,
						"<span style='color:steelblue'>Object Parent : </span>" + MasterScriptMapping.strParent);
				logger.log(LogStatus.INFO,
						"<span style='color:steelblue'>Object Child : </span>" + MasterScriptMapping.strChild);
				we = GetObj(MasterScriptMapping.strChild);
				((JavascriptExecutor) MasterScriptMapping.driver).executeScript("arguments[0].scrollIntoView();", we);
				MasterScriptMapping.dynamicWait.until(ExpectedConditions.visibilityOf(we));
				we.clear();
				MasterScriptMapping.sActualResult = "<span style='color:steelblue;font-weight:bold;'>Element: '"
						+ strClearText + "' has been cleared successfully </span>";
				logger.log(LogStatus.PASS, MasterScriptMapping.sActualResult);
				MasterScriptMapping.sKeywordStatus = "0";
			} else {
				logger.log(LogStatus.SKIP,
						"<span style='color:steelblue;font-weight:bold;'>Keyword Skipped - ClearText</span>");
				MasterScriptMapping.sKeywordStatus = "2";
			}
		} catch (Exception e) {
			MasterScriptMapping.sActualResult = e.getMessage();
			logger.log(LogStatus.FATAL,
					"<span style='color:steelblue;font-weight:bold;'>Exception Occured - Keyword ClearText : </span>"
							+ e);
			MasterScriptMapping.sKeywordStatus = "1";
		}
	}

	//
	public static void SelectValueVIT() {
		try {
			String strSelectValueType = KeywordRepository.GetData(MasterScriptMapping.Param1);
			String strSelectValueData = KeywordRepository.GetData(MasterScriptMapping.Param2);
			logger.log(LogStatus.INFO,
					"<span style='color:steelblue'>Object Parent : </span>" + MasterScriptMapping.strParent);
			logger.log(LogStatus.INFO,
					"<span style='color:steelblue'>Object Child : </span>" + MasterScriptMapping.strChild);
			we = GetObj(MasterScriptMapping.strChild);
			((JavascriptExecutor) MasterScriptMapping.driver).executeScript("arguments[0].scrollIntoView();", we);
			MasterScriptMapping.dynamicWait.until(ExpectedConditions.visibilityOf(we));
			Select oselect = new Select(we);
			logger.log(LogStatus.INFO,
					"<span style='color:steelblue'>SelectByType : </span>" + MasterScriptMapping.Param1);
			logger.log(LogStatus.INFO,
					"<span style='color:steelblue'>SelectByTypeData : </span>" + MasterScriptMapping.Param2);
			try {
				if (!(strSelectValueType.equalsIgnoreCase("selectByValue")
						|| strSelectValueType.equalsIgnoreCase("selectByText")
						|| strSelectValueType.equalsIgnoreCase("selectByIndex"))) {
					strSelectValueType = "selectByText";
				}
			} catch (Exception e) {
				MasterScriptMapping.sActualResult = e.getMessage();
				logger.log(LogStatus.FATAL,
						"<span style='color:steelblue;font-weight:bold;'>Exception Occured - SelectByType in PARAM1 is not correctly defined : </span>"
								+ e);
				MasterScriptMapping.sKeywordStatus = "1";
			}
			if (strSelectValueType.equalsIgnoreCase("selectByValue")) {
				oselect.selectByValue(strSelectValueData);
				MasterScriptMapping.sActualResult = "<span style='color:steelblue'>Element: '" + strSelectValueData
						+ "' has been selected successfully</span>";
				logger.log(LogStatus.PASS, MasterScriptMapping.sActualResult);
				MasterScriptMapping.sKeywordStatus = "0";
			} else if (strSelectValueType.equalsIgnoreCase("selectByText")) {
				List<WebElement> allOptions = oselect.getOptions();
				int index = 0;
				for (int i = 0; i <= allOptions.size() - 1; i++) {
					if (strSelectValueData.trim().replaceAll("\\s+", " ")
							.equalsIgnoreCase(allOptions.get(i).getText().trim().replaceAll("\\s+", " "))) {
						break;
					}
					index++;
				}
				oselect.selectByIndex(index);
				MasterScriptMapping.sActualResult = "<span style='color:steelblue'>Element: '" + strSelectValueData
						+ "' has been selected successfully </span>";
				logger.log(LogStatus.PASS, MasterScriptMapping.sActualResult);
				MasterScriptMapping.sKeywordStatus = "0";
			} else if (strSelectValueType.equalsIgnoreCase("selectByIndex")) {
				int index_data = Integer.parseInt(strSelectValueData);
				oselect.selectByIndex(index_data);
				MasterScriptMapping.sActualResult = "<span style='color:steelblue'>Element: '" + strSelectValueData
						+ "' has been selected successfully </span>";
				logger.log(LogStatus.PASS, MasterScriptMapping.sActualResult);
				MasterScriptMapping.sKeywordStatus = "0";
			}
		} catch (Exception e) {
			MasterScriptMapping.sActualResult = e.getMessage();
			logger.log(LogStatus.FATAL,
					"<span style='color:steelblue;font-weight:bold;'>Exception Occured - SelectValueVIT : </span>" + e);
			MasterScriptMapping.sKeywordStatus = "1";
		}
	}

	//
	public static void VerifyTextOnPage() {
		try {
			String strVerifyTextOnPage = KeywordRepository.GetData(MasterScriptMapping.Param1);
			MasterScriptMapping.dynamicWait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//*[contains(text(),'" + strVerifyTextOnPage + "')]")));
			logger.log(LogStatus.INFO,
					"<span style='color:steelblue'>Find Text On Page : </span>" + MasterScriptMapping.Param1);
			if (MasterScriptMapping.driver.getPageSource().contains(strVerifyTextOnPage)) {
				MasterScriptMapping.sActualResult = "<span style='color:steelblue;font-weight:bold;'>Text: '"
						+ strVerifyTextOnPage + "' found </span>";
				logger.log(LogStatus.PASS, MasterScriptMapping.sActualResult);
				MasterScriptMapping.sKeywordStatus = "0";
			} else {
				MasterScriptMapping.sActualResult = "<span style='color:steelblue;font-weight:bold;'>Text: '"
						+ strVerifyTextOnPage + "' can not be found </span>";
				logger.log(LogStatus.PASS, MasterScriptMapping.sActualResult);
				MasterScriptMapping.sKeywordStatus = "1";
			}
			if(MasterScriptMapping.driver.getPageSource().contains("Review Order")) {
				JFrame frame = new JFrame("JOptionPane showMessageDialog example");
   			   	JOptionPane.showMessageDialog(frame,"Order Submitted Successfully","ATO",JOptionPane.PLAIN_MESSAGE);
   	 			}

		} catch (Exception e) {
			MasterScriptMapping.sActualResult = e.getMessage();
			logger.log(LogStatus.FATAL,
					"<span style='color:steelblue;font-weight:bold;'>Exception Occured - Keyword VerifyTextOnPage : </span>"
							+ e);
			MasterScriptMapping.sKeywordStatus = "1";
		}
	}
	
	public static void isDisplayed() {
		try {
			String strClickElement = KeywordRepository.GetData(MasterScriptMapping.Param1);
			if (!strClickElement.equals(null) && !strClickElement.equals("")) {
				logger.log(LogStatus.INFO,
						"<span style='color:steelblue'>Object Parent : </span>" + MasterScriptMapping.strParent);
				logger.log(LogStatus.INFO,
						"<span style='color:steelblue'>Object Child : </span>" + MasterScriptMapping.strChild);
			we = GetObj(MasterScriptMapping.strChild);
			logger.log(LogStatus.INFO,
					"<span style='color:steelblue'>Find Text On Page : </span>" + MasterScriptMapping.Param1);
			if(we.isDisplayed()) {
				JFrame frame = new JFrame("JOptionPane showMessageDialog example");
   			   	JOptionPane.showMessageDialog(frame,"Order Submitted Successfully","ATO",JOptionPane.PLAIN_MESSAGE);
   	 			}
			}
		} catch (Exception e) {
			MasterScriptMapping.sActualResult = e.getMessage();
			logger.log(LogStatus.FATAL,
					"<span style='color:steelblue;font-weight:bold;'>Exception Occured - Keyword ElementIsDisplayed : </span>"
							+ e);
			MasterScriptMapping.sKeywordStatus = "1";
		}
	}

	//
	public static void VerifyTitle() {
		try {
			String strVerifyTitleOnPage = KeywordRepository.GetData(MasterScriptMapping.Param1);
			logger.log(LogStatus.INFO,
					"<span style='color:steelblue'>Find Text On Page : </span>" + MasterScriptMapping.Param1);
			MasterScriptMapping.dynamicWait.until(ExpectedConditions.titleContains(strVerifyTitleOnPage));
			if (MasterScriptMapping.driver.getTitle().contains(strVerifyTitleOnPage)) {
				MasterScriptMapping.sActualResult = "<span style='color:steelblue;font-weight:bold;'>Title: '"
						+ strVerifyTitleOnPage + "' found </span>";
				logger.log(LogStatus.PASS, MasterScriptMapping.sActualResult);
				MasterScriptMapping.sKeywordStatus = "0";
			} else {
				MasterScriptMapping.sActualResult = "<span style='color:steelblue;font-weight:bold;'>Title: '"
						+ strVerifyTitleOnPage + "' can not be found </span>";
				logger.log(LogStatus.PASS, MasterScriptMapping.sActualResult);
				MasterScriptMapping.sKeywordStatus = "1";
			}

		} catch (Exception e) {
			MasterScriptMapping.sActualResult = e.getMessage();
			logger.log(LogStatus.FATAL,
					"<span style='color:steelblue;font-weight:bold;'>Exception Occured - Keyword VerifyTitle : </span>"
							+ e);
			MasterScriptMapping.sKeywordStatus = "1";
		}
	}

	//
	public static void ClickDataInTable() throws InterruptedException {
		String col1 = null;
		String col2 = null;
		int[] column_numbers;
		int k1, col_no1, k2 = 0;
		int col_no2;
		try {
			// Xpath For Table
			we = GetObj(MasterScriptMapping.strChild);
			((JavascriptExecutor) MasterScriptMapping.driver).executeScript("arguments[0].scrollIntoView();", we);
			MasterScriptMapping.dynamicWait.until(ExpectedConditions.visibilityOf(we));
			// param1
			String column_Name = KeywordRepository.GetData(MasterScriptMapping.Param1);
			logger.log(LogStatus.INFO, "<span style='color:steelblue'>Headers : </span>" + column_Name);
			String[] column_Names = column_Name.trim().split(";");
			column_numbers = new int[column_Names.length];
			List<WebElement> table_headings = null;
			if (column_numbers.length <= 1) {
				col1 = column_Names[0].toString();
				col2 = "";
			}
			if (column_numbers.length > 1) {
				col1 = column_Names[0].toString();
				col2 = column_Names[1].toString();
			}
			table_headings = we.findElements(By.tagName("th"));
			MasterScriptMapping.dynamicWait.until(ExpectedConditions.visibilityOfAllElements(table_headings));
			if (table_headings != null && table_headings.size() > 0) {
				for (k1 = 0; k1 < table_headings.size(); k1++) {
					if (table_headings.get(k1).getText().trim().equalsIgnoreCase(col1)
							&& (col2 == "" || col2 == null || col2.isEmpty())) {
						col_no1 = k1;
						column_numbers[0] = col_no1;
						break;
					}
					if (table_headings.get(k1).getText().trim().equalsIgnoreCase(col1)
							&& (!col2.isEmpty() || col2 != "" || col2 != null)) {
						col_no1 = k1;
						k2 = ++k1;
						if (table_headings.get(k1).getText().trim().equalsIgnoreCase(col2)) {
							col_no2 = k2;
							column_numbers[0] = col_no1;
							column_numbers[1] = col_no2;
							break;
						}
						break;
					}
				}
			} else {
				logger.log(LogStatus.FATAL,
						"<span style='color:steelblue;font-weight:bold;'>Error Fetching Headers : </span>"
								+ column_Name);
			}
			Thread.sleep(100);
			int[] col_index = column_numbers;
			int col1_index = 0;
			int col2_index = 0;
			String search_value1 = null;
			String search_value2 = null;
			List<WebElement> cells;
			String cell1 = null;
			String cell2 = null;
			int flagValNotFound = 0;
			// param 3
			String action = KeywordRepository.GetData(MasterScriptMapping.Param3);
			logger.log(LogStatus.INFO, "<span style='color:steelblue'>Action To Take : </span>" + action);
			if (col_index.length > 1) {
				col1_index = col_index[0];
				col2_index = col_index[1];
			}
			if (col_index.length <= 1) {
				col1_index = col_index[0];
			}
			// param 2
			String search_value = KeywordRepository.GetData(MasterScriptMapping.Param2);
			logger.log(LogStatus.INFO,
					"<span style='color:steelblue'>Cell Value To Take Action On : </span>" + search_value);
			String[] search_values = search_value.trim().split(";");
			if (search_values.length <= 1) {
				search_value1 = search_values[0].toString();
				search_value2 = "";
			}
			if (search_values.length > 1) {
				search_value1 = search_values[0].toString();
				search_value2 = search_values[1].toString();
			}
			List<WebElement> rows = we.findElements(By.tagName("tr"));
			Thread.sleep(10);
			for (int i = 0; i < rows.size(); i++) {
				cells = rows.get(i).findElements(By.tagName("td"));
				Thread.sleep(10);
				if (i == 0) {
					continue;
				}
				if (col_index.length <= 1) {
					cell1 = cells.get(col1_index).getText().trim();
					cell2 = "";
				}
				if (col_index.length > 1) {
					cell1 = cells.get(col1_index).getText().trim();
					cell2 = cells.get(col2_index).getText().trim();
				}
				if (cell1.equalsIgnoreCase(search_value1) && (cell2.isEmpty() || cell2 == "" || cell2 == null)) {
					try {
						for (int j = col1_index; j <= table_headings.size(); j++) {
							cell1 = cells.get(j).getText().trim();
							System.out.println("ACTION" + cell1);
							if (cell1.contains(action)) {
								System.out.println("TESTING VALUE" + cell1);
								MasterScriptMapping.driver.manage().window().setSize(new Dimension(1024, 768));
								cells.get(j).click();
								logger.log(LogStatus.PASS, "<span style='color:steelblue;font-weight:bold;'>Object : '"
										+ cells.get(j) + "' clicked sucessfully </span>");
								MasterScriptMapping.sKeywordStatus = "0";
								Thread.sleep(10);
								MasterScriptMapping.driver.manage().window().maximize();
								flagValNotFound = 1;
								break;
							}
						}
					} catch (Exception e) {
						logger.log(LogStatus.FATAL,
								"<span style='color:steelblue;font-weight:bold;'>Value Not Found : </span>" + e);
						MasterScriptMapping.sKeywordStatus = "1";
						break;
					}
				}
				if (!cell2.equals("")) {
					if (cell1.equalsIgnoreCase(search_value1) && cell2.equalsIgnoreCase(search_value2)) {
						try {
							for (int j = col2_index + 1; j <= table_headings.size(); j++) {
								cell1 = cells.get(j).getText().trim();
								if (cell1.contains(action)) {
									System.out.println("TESTING VALUE 2" + cell1);
									MasterScriptMapping.driver.manage().window().setSize(new Dimension(1024, 768));
									cells.get(j).click();
									logger.log(LogStatus.PASS,
											"<span style='color:steelblue;font-weight:bold;'>Object : '" + action
													+ "' clicked sucessfully </span>");
									MasterScriptMapping.sKeywordStatus = "0";
									Thread.sleep(10);
									MasterScriptMapping.driver.manage().window().maximize();
									flagValNotFound = 1;
									break;
								}
							}
						} catch (Exception e) {
							logger.log(LogStatus.FATAL,
									"<span style='color:steelblue;font-weight:bold;'>Value Not Found : </span>" + e);
							MasterScriptMapping.sKeywordStatus = "1";
							break;
						}
						break;
					}
				}
				if ((cell2.isEmpty() || cell2 == "" || cell2 == null)
						&& (cell1.isEmpty() || cell1 == "" || cell1 == null)) {
					logger.log(LogStatus.FAIL,
							"<span style='color:steelblue;font-weight:bold;'>Action Data Not Found </span>");
					MasterScriptMapping.sKeywordStatus = "1";
					break;
				}
			}
			if (flagValNotFound == 0) {
				logger.log(LogStatus.INFO,
						"<span style='color:steelblue;font-weight:bold;'>No Cell Data Found To Click : PARAM 2 </span>");
				MasterScriptMapping.sKeywordStatus = "1";
			}
		} catch (Exception e) {
			logger.log(LogStatus.FATAL,
					"<span style='color:steelblue;font-weight:bold;'>Exception In Fetching Table : </span>" + e);
			MasterScriptMapping.sKeywordStatus = "1";
		}
	}

	//
	public static void VerifyDataInTable() throws InterruptedException {
		try {
			int[] column_numbers;
			int k1, col_no1, k2 = 0;
			int col_no2;
			String col1 = null;
			String col2 = null;
			// Xpath of Table
			we = GetObj(MasterScriptMapping.strChild);
			((JavascriptExecutor) MasterScriptMapping.driver).executeScript("arguments[0].scrollIntoView();", we);
			MasterScriptMapping.dynamicWait.until(ExpectedConditions.visibilityOf(we));
			// param1
			String column_Name = KeywordRepository.GetData(MasterScriptMapping.Param1);
			String[] column_Names = column_Name.trim().split(";");
			column_numbers = new int[column_Names.length];
			logger.log(LogStatus.INFO, "<span style='color:steelblue'>Column Header : </span>" + column_Name);
			List<WebElement> table_headings = null;
			if (column_numbers.length <= 1) {
				col1 = column_Names[0].toString();
				col2 = "";
			}
			if (column_numbers.length > 1) {
				col1 = column_Names[0].toString();
				col2 = column_Names[1].toString();
			}
			table_headings = we.findElements(By.tagName("th"));
			MasterScriptMapping.dynamicWait.until(ExpectedConditions.visibilityOfAllElements(table_headings));
			if (table_headings != null && table_headings.size() > 0) {
				for (k1 = 0; k1 < table_headings.size(); k1++) {
					if (table_headings.get(k1).getText().trim().equalsIgnoreCase(col1)
							&& (col2 == "" || col2 == null || col2.isEmpty())) {
						col_no1 = k1;
						column_numbers[0] = col_no1;
						break;
					}
					if (table_headings.get(k1).getText().trim().equalsIgnoreCase(col1)
							&& (!col2.isEmpty() || col2 != "" || col2 != null)) {
						col_no1 = k1;
						k2 = ++k1;
						if (table_headings.get(k1).getText().trim().equalsIgnoreCase(col2)) {
							col_no2 = k2;
							column_numbers[0] = col_no1;
							column_numbers[1] = col_no2;
							break;
						}
						break;
					}
				}
			} else {
				logger.log(LogStatus.FAIL,
						"<span style='color:steelblue;font-weight:bold;'>No Column Header Found For  : </span>"
								+ column_Name);
				MasterScriptMapping.sKeywordStatus = "1";
			}
			// Works on Fetched Headers
			Thread.sleep(100);
			int[] col_index = column_numbers;
			int col1_index = 0;
			int col2_index = 0;
			int flagValNotFound = 0;
			String search_value1 = null;
			String search_value2 = null;
			List<WebElement> cells;
			String cell1 = null;
			String cell2 = null;
			// param 2
			String search_value = KeywordRepository.GetData(MasterScriptMapping.Param2);
			String[] search_values = search_value.trim().split(";");
			logger.log(LogStatus.INFO, "<span style='color:steelblue'>Cell Data To Fetch : </span>" + search_value);
			if (search_values.length <= 1) {
				search_value1 = search_values[0].toString();
				search_value2 = "";
			}
			if (search_values.length > 1) {
				search_value1 = search_values[0].toString();
				search_value2 = search_values[1].toString();
			}
			// param 3
			String action = KeywordRepository.GetData(MasterScriptMapping.Param3);
			logger.log(LogStatus.INFO, "<span style='color:steelblue'>Value To Verify : </span>" + action);
			if (col_index.length > 1) {
				col1_index = col_index[0];
				col2_index = col_index[1];
			}
			if (col_index.length <= 1) {
				col1_index = col_index[0];
			}
			List<WebElement> rows = we.findElements(By.tagName("tr"));
			Thread.sleep(10);
			for (int i = 0; i < rows.size(); i++) {
				cells = rows.get(i).findElements(By.tagName("td"));
				Thread.sleep(10);
				if (i == 0) {
					continue;
				}
				if (col_index.length <= 1) {
					cell1 = cells.get(col1_index).getText().trim();
					cell2 = "";
				}
				if (col_index.length > 1) {
					cell1 = cells.get(col1_index).getText().trim();
					cell2 = cells.get(col2_index).getText().trim();
				}
				if (cell2.isEmpty() || cell2 == "" || cell2 == null) {
					System.out.println("First IF");
					Thread.sleep(100);
					if (cell1.equalsIgnoreCase(search_value1)) {
						try {
							for (int j = col1_index; j <= table_headings.size(); j++) {
								cell1 = cells.get(j).getText().trim();
								if (cell1.contains(action)) {
									Thread.sleep(10);
									logger.log(LogStatus.PASS,
											"<span style='color:steelblue;font-weight:bold;'>Value :  '" + action
													+ "' Found successfully</span>");
									MasterScriptMapping.sKeywordStatus = "0";
									flagValNotFound = 1;
									break;
								}
							}
						} catch (Exception e) {
							MasterScriptMapping.sKeywordStatus = "1";
							break;
						}
					}
				}
				if (!cell2.equals("")) {
					System.out.println("Second IF");
					Thread.sleep(100);
					if (cell1.equalsIgnoreCase(search_value1) && cell2.equalsIgnoreCase(search_value2)) {
						System.out.println("Second IF---1");
						try {
							for (int j = col2_index; j <= table_headings.size(); j++) {
								cell1 = cells.get(j).getText().trim();
								if (cell1.contains(action)) {
									System.out.println("In the IF");
									Thread.sleep(10);
									logger.log(LogStatus.PASS,
											"<span style='color:steelblue;font-weight:bold;'>Value :  '" + action
													+ "' Found successfully</span>");
									MasterScriptMapping.sKeywordStatus = "0";
									flagValNotFound = 1;
									break;
								}
							}
						} catch (Exception e) {
							MasterScriptMapping.sKeywordStatus = "1";
							e.printStackTrace();
							break;
						}
					}
				}
				if ((cell2.isEmpty() || cell2 == "" || cell2 == null)
						&& (cell1.isEmpty() || cell1 == "" || cell1 == null)) {
					logger.log(LogStatus.INFO,
							"<span style='color:steelblue;font-weight:bold;'>No Cell Data Found : PARAM 2 </span>");
					MasterScriptMapping.sKeywordStatus = "1";
					break;
				}
			}
			if (flagValNotFound == 0) {
				logger.log(LogStatus.INFO,
						"<span style='color:steelblue;font-weight:bold;'>No Cell Data Found : PARAM 2 </span>");
				MasterScriptMapping.sKeywordStatus = "1";
			}
		} catch (Exception e) {
			logger.log(LogStatus.FATAL,
					"<span style='color:steelblue;font-weight:bold;'>Exception Occured For Keyword - VerifyDataInTable : </span>"
							+ e);
			MasterScriptMapping.sKeywordStatus = "1";
		}
	}

	public static void SendKeysAndEnter() throws Exception {
		try {
			String strClickElement = KeywordRepository.GetData(MasterScriptMapping.Param1);
			logger.log(LogStatus.INFO,
					"<span style='color:steelblue'>Object Parent : </span>" + MasterScriptMapping.strParent);
			logger.log(LogStatus.INFO,
					"<span style='color:steelblue'>Object Child : </span>" + MasterScriptMapping.strChild);
			we = GetObj(MasterScriptMapping.strChild);
			((JavascriptExecutor) MasterScriptMapping.driver).executeScript("arguments[0].scrollIntoView();", we);
			MasterScriptMapping.dynamicWait.until(ExpectedConditions.visibilityOf(we));
			Actions action = new Actions(MasterScriptMapping.driver);
			action.moveToElement(we).build().perform();
			if (strClickElement.equalsIgnoreCase("DOWN")) {
				we.sendKeys(Keys.ARROW_DOWN);
				we.sendKeys(Keys.ENTER);
			}
			if (strClickElement.equalsIgnoreCase("UP")) {
				we.sendKeys(Keys.ARROW_UP);
				we.sendKeys(Keys.ENTER);
			}
			MasterScriptMapping.sActualResult = "<span style='color:steelblue;font-weight:bold;'>Keys: '"
					+ strClickElement + "' has been sent keys successfully</span>";
			logger.log(LogStatus.PASS, MasterScriptMapping.sActualResult);
			MasterScriptMapping.sKeywordStatus = "0";
		} catch (Exception e) {
			MasterScriptMapping.sActualResult = e.getMessage();
			logger.log(LogStatus.FATAL,
					"<span style='color:steelblue;font-weight:bold;'>Exception Occured - Keyword ClickElement : </span>"
							+ e);
			MasterScriptMapping.sKeywordStatus = "1";
		}
	}

	public static void SendKeys() throws Exception {
		try {
			String strClickElement = KeywordRepository.GetData(MasterScriptMapping.Param1);
			logger.log(LogStatus.INFO,
					"<span style='color:steelblue'>Object Parent : </span>" + MasterScriptMapping.strParent);
			logger.log(LogStatus.INFO,
					"<span style='color:steelblue'>Object Child : </span>" + MasterScriptMapping.strChild);
			we = GetObj(MasterScriptMapping.strChild);
			((JavascriptExecutor) MasterScriptMapping.driver).executeScript("arguments[0].scrollIntoView();", we);
			MasterScriptMapping.dynamicWait.until(ExpectedConditions.visibilityOf(we));
			Actions action = new Actions(MasterScriptMapping.driver);
			action.moveToElement(we).build().perform();
			if (strClickElement.equalsIgnoreCase("ENTER")) {
				we.sendKeys(Keys.ENTER);
			}
			if (strClickElement.equalsIgnoreCase("UP")) {
				we.sendKeys(Keys.ARROW_UP);
			}
			if (strClickElement.equalsIgnoreCase("DOWN")) {
				we.sendKeys(Keys.ARROW_DOWN);
			}
			if (strClickElement.equalsIgnoreCase("LEFT")) {
				we.sendKeys(Keys.ARROW_LEFT);
			}
			if (strClickElement.equalsIgnoreCase("RIGHT")) {
				we.sendKeys(Keys.ARROW_RIGHT);
			}
			if (strClickElement.equalsIgnoreCase("TAB")) {
				we.sendKeys(Keys.TAB);
			}
			MasterScriptMapping.sActualResult = "<span style='color:steelblue;font-weight:bold;'>Keys: '"
					+ strClickElement + "' has been sent keys successfully</span>";
			logger.log(LogStatus.PASS, MasterScriptMapping.sActualResult);
			MasterScriptMapping.sKeywordStatus = "0";
		} catch (Exception e) {
			MasterScriptMapping.sActualResult = e.getMessage();
			logger.log(LogStatus.FATAL,
					"<span style='color:steelblue;font-weight:bold;'>Exception Occured - Keyword ClickElement : </span>"
							+ e);
			MasterScriptMapping.sKeywordStatus = "1";
		}
	}
}